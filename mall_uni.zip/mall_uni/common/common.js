import http from '@/common/http.interceptor.js';
const format = function format(a) {
	return a
    a = Number(a);
    var arr = new Array();
    var xiaoshu = ""; //用来记录参数小数数值包括小数点
    var zhengshu = ""; //用来记录参数录整数数值
    if (a < 1000) { //当参数小于1000的时候直接返回参数
	 var t = a.toString(); //将整数转换成字符串
		if(t.indexOf('.') > 0){
			let notDot = t.substring(0,t.indexOf('.'))
			return notDot
		}else{
			return a;
		}
        
    } else {
        var t = a.toString(); //将整数转换成字符串
        if (t.indexOf('.') > 0) { //如果参数存在小数，则记录小数部分与整数部分
            var index = t.indexOf('.');
            xiaoshu = t.slice(index, t.length);
            zhengshu = t.slice(0, index);
        } else { //否则整数部分的值就等于参数的字符类型
            zhengshu = t;
        }
        var num = parseInt(zhengshu.length / 3); //判断需要插入千位分割符的个数

        //将整数1234567890部分拆分为2部分，变量head:1   变量body:123456789
        var head = zhengshu.slice(0, zhengshu.length - num * 3);
        if (head.length > 0) { //如果head存在，则在head后面加个千位分隔符，
            head += ',';
        }
        var body = zhengshu.slice(zhengshu.length - num * 3, zhengshu.length);

        //将body字符串123456789转换成一个字符数组arr2 = ['123','456','789']
        var arr2 = new Array();
        for (var i = 0; i < num; i++) {
            arr2.push(body.slice(i * 3, i * 3 + 3));
        }
        body = arr2.join(','); //将数组arr2通过join(',')   方法，拼接成一个以逗号为间隔的字符串

        zhengshu = head + body; //拼接整数部分
        // var result = zhengshu + xiaoshu; //最后拼接整数和小数部分
		var result = zhengshu; //最后拼接整数和小数部分
        return result; //返回结果
    }
}
const getCurrentDate =  function getCurrentDate(date,format) {
		date = date.replace(/-/g,'/')
      var now = new Date(date);
      var year = now.getFullYear(); //得到年份
      var month = now.getMonth();//得到月份
      var date = now.getDate();//得到日期
      var day = now.getDay();//得到周几
      var hour = now.getHours();//得到小时
      var minu = now.getMinutes();//得到分钟
      var sec = now.getSeconds();//得到秒
      month = month + 1;
      if (month < 10) month = "0" + month;
      if (date < 10) date = "0" + date;
      if (hour < 10) hour = "0" + hour;
      if (minu < 10) minu = "0" + minu;
      if (sec < 10) sec = "0" + sec;
      var time = "";
      //精确到天
      if(format==1){
        time = date + "-" + month +"-"+year
      }
      //精确到分
      else if(format==2){
        time = sec + ":" + minu + ":" + hour + " " +  date + "-" +  month + "-" +  year;
      }
      return time;
    }

export default {  
    format,
	getCurrentDate
}