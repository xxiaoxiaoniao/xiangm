const http = uni.$u.http

// post请求，获取商品
export const goods = (params, config = {}) => http.post('/mall_web/goods/goods', params, config)

//登录 
export const login = (params, config = {}) => http.post('/mall_web/user/userLogin', params, config)

//注册
export const userRegistration = (params, config = {}) => http.post('/mall_web/user/userRegistration', params, config)

//查询用户名是否可用
export const queryUserName = (params, config = {}) => http.post('/mall_web/user/queryUserName', params, config)


//获取商品分类
export const classification = (params, config = {}) => http.post('/mall_web/goods/classification', params, config)

//获取商品二级分类
export const mallSort = (params, config = {}) => http.post('/mall_web/goods/mallSort', params, config)

//获取国家和地区
export const countryRegion = (params, config = {}) => http.post('/mall_web/country_region/countryRegion', params, config)

//获取用户的全部好友
export const allFriends = (params, config = {}) => http.post('/mall_web/user_friend/allFriends', params, config)


// get请求
// export const getMenu = (data) => http.get('/ebapi/public_api/index', data)

// 默认全部导出
export default {
    goods,
	login,
	userRegistration,
	queryUserName,
	classification,
	mallSort,
	countryRegion,
	allFriends
	
}