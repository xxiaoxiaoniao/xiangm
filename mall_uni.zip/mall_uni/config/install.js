import apis from 'config/api.js'
const install = Vue => {        // install：安装
    if (install.installed) {
        return;
    } else {
        install.installed = true;
    };
    Object.defineProperties(Vue.prototype, {
        // 此处挂载在 Vue 原型的 $api 对象上
        api: {
            get() {
                return apis;
            }
        }
    })
}
export default install;