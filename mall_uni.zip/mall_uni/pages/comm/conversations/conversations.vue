<template>
	<scroll-view class="conversations" scroll-y="true">
		<view class='dingbu'>
			<view class='biaoti'>消息</view>
			<image @click='menu_type=!menu_type' style='width: 38rpx;height: 38rpx;margin-right: 20rpx;' src='/static/comm-images/liaotian/add_.png'></image>
			<view v-if='menu_type' style='position: absolute;right: 32rpx;'>
				<view class='sanjiaoxing'></view>
				<view class='leftMenu'>
					<view class='items' v-for="(v,i) in subMenu" :key='i'>
						<image style='width: 37rpx;height: 37rpx;' :src='v.icon'></image>
						<view><text>{{v.title}}</text></view>
					</view>
				</view>
			</view>
		</view>
		<view class="scroll-item">
			<view class="item-head">
				<image src="/static/comm-images/liaotian/kefu1.png" class="head-icon"></image>
				<!-- <view class="item-head_unread"></view> -->
			</view>
			<view class="scroll-item_info">
				<view class="item-info-top">
					<text class="item-info-top_name">小客服</text>
				</view>
				<view class="item-info-bottom">
					<view class="item-info-bottom-item">
						<view class="item-info-top_content">你的好友给您点了个赞</view>
					</view>
				</view>
			</view>
		</view>
		<view class="scroll-item">
			<view class="item-head">
				<image src="/static/comm-images/liaotian/tongzhi.png" class="head-icon"></image>
			</view>
			<view class="scroll-item_info">
				<view class="item-info-top">
					<text class="item-info-top_name">互动通知</text>
				</view>
				<view class="item-info-bottom">
					<view class="item-info-bottom-item">
						<view class="item-info-top_content">赞了您的动态</view>
					</view>
				</view>
			</view>
		</view>
		<view v-if="conversations.length !=0">
			<view class="scroll-item" v-for="(conversation, key) in conversations" :key="key">
				<view class="item-head">
					<image :src="conversation.data.avatar" class="head-icon"></image>
					<view class="item-head_unread" v-if="conversation.unread">{{conversation.unread}}</view>
				</view>
				<view class="scroll-item_info">
					<view class="item-info-top">
						<text class="item-info-top_name">{{conversation.data.name}}</text>
						<view class="item-info-top_time">{{formatDate(conversation.lastMessage.timestamp)}}</view>
					</view>
					<view class="item-info-bottom">
						<view class="item-info-bottom-item" @click="navigateToChat(conversation)">
							<view class="item-info-top_content" v-if="conversation.lastMessage.type == 'text'">
								{{conversation.lastMessage.payload.text}}</view>
							<view class="item-info-top_content" v-else-if="conversation.lastMessage.type == 'video'">
								[视频消息]</view>
							<view class="item-info-top_content" v-else-if="conversation.lastMessage.type == 'audio'">
								[语音消息]</view>
							<view class="item-info-top_content" v-else-if="conversation.lastMessage.type == 'image'">
								[图片消息]</view>
							<view class="item-info-top_content" v-else-if="conversation.lastMessage.type == 'file'">
								[文件消息]</view>
							<view class="item-info-top_content" v-else-if="conversation.lastMessage.type == 'order'">
								[自定义消息:订单]</view>
							<view class="item-info-top_content" v-else>[[未识别内容]]</view>
							<view class="item-info-bottom_action" @click.stop="showAction(conversation)"></view>
						</view>
					</view>
				</view>
			</view>
		</view>
		<view class="no-conversation" v-else>
			当前没有会话
		</view>
		<view class="action-container" v-if="action.show">
			<view class="layer" @click="action.show = false"></view>
			<view class="action-box">
				<view class="action-item" @click="topConversation">{{action.conversation.top ? '取消置顶' : '置顶'}}</view>
				<view class="action-item" @click="removeConversation">移除</view>
			</view>
		</view>
	</scroll-view>
</template>

<script>
	import IMService from "../../../lib/imservice";
	export default {
		name: "contacts",
		data() {
			return {
				menu_type:false,
				subMenu: [{
						title: '发起聊天',
						icon: '/static/comm-images/liaotian/faqiliaotian.png'
					},
					{
						title: '添加朋友',
						icon: '/static/comm-images/liaotian/tianjapengyou.png'
					},
					{
						title: '通讯录',
						icon: '/static/comm-images/liaotian/tongxunlu.png'
					}
				],
				unreadTotal: 0,
				conversations: [],
				action: {
					conversation: null,
					show: false
				}
			}
		},
		onShow() {
			
			
			
			
			uni.showLoading();
			//监听会话列表变化
			let self = this;
			this.goEasy.im.on(this.GoEasy.IM_EVENT.CONVERSATIONS_UPDATED, (content) => {
				console.log('我执行了this.goEasy.im.on')
				self.renderConversations(content);
			});
			//加载会话列表
			this.goEasy.im.latestConversations({
				onSuccess: function(result) {
					console.log(result,'this.goEasy.im.latestConversations')
					let content = result.content;
					self.renderConversations(content);
					uni.hideLoading();
				},
				onFailed: function(error) {
					//获取失败
					uni.hideLoading()
					console.log("失败获取最新会话列表, code:" + error.code + " content:" + error.content);
				}
			});
		},

		methods: {
			topConversation() {
				uni.showLoading({
					title: "加载中...",
					mask: true
				});
				let conversation = this.action.conversation;
				let failedDescription = conversation.top ? '取消置顶失败' : '置顶失败';
				this.action.show = false;
				if (conversation.type === this.GoEasy.IM_SCENE.PRIVATE) {
					this.goEasy.im.topPrivateConversation({
						userId: conversation.userId,
						top: !conversation.top,
						onSuccess: function() {
							uni.hideLoading();
						},
						onFailed: function(error) {
							uni.hideLoading();
							uni.showToast({
								title: failedDescription,
								icon: "none"
							});
							console.log(error);
						}
					});
				} else {
					this.goEasy.im.topGroupConversation({
						groupId: conversation.groupId,
						top: !conversation.top,
						onSuccess: function() {
							uni.hideLoading();
						},
						onFailed: function(error) {
							uni.hideLoading();
							uni.showToast({
								title: failedDescription,
								icon: "none"
							});
							console.log(error);
						}
					});
				}
			},
			removeConversation() {
				uni.showLoading({
					title: "加载中...",
					mask: true
				});
				let failedDescription = "删除失败";
				let conversation = this.action.conversation;
				this.action.show = false;
				if (conversation.type === this.GoEasy.IM_SCENE.PRIVATE) {
					this.goEasy.im.removePrivateConversation({
						userId: conversation.userId,
						onSuccess: function() {
							uni.hideLoading();
						},
						onFailed: function(error) {
							uni.hideLoading();
							uni.showToast({
								title: failedDescription,
								icon: "none"
							});
							console.log(error);
						}
					});
				} else {
					this.goEasy.im.removeGroupConversation({
						groupId: conversation.groupId,
						onSuccess: function() {
							uni.hideLoading()
						},
						onFailed: function(error) {
							uni.hideLoading();
							uni.showToast({
								title: failedDescription,
								icon: "none"
							});
							console.log(error);
						}
					});
				}
			},
			renderConversations(content) {
				this.conversations = content.conversations || [];
				let unreadTotal = content.unreadTotal;
				this.setUnreadAmount(unreadTotal);
			},
			setUnreadAmount(unreadTotal) {
				this.unreadTotal = unreadTotal;
				if (this.unreadTotal > 0) {
					uni.setTabBarBadge({
						index: 3,
						text: this.unreadTotal.toString()
					});
				} else {
					uni.removeTabBarBadge({
						index: 3
					});
				}
			},
			navigateToChat(conversation) {
				let path = conversation.type === this.GoEasy.IM_SCENE.PRIVATE ?
					'../chat/privateChat/privateChat?to=' + conversation.userId :
					'../chat/groupChat/groupChat?to=' + conversation.groupId;
				uni.navigateTo({
					url: path
				});
			},
			showAction(conversation) {
				this.action.conversation = conversation;
				this.action.show = true;
			}
		}
	}
</script>

<style lang="scss">
	.dingbu {
		position: relative;
		background: #f7f7f7;
		padding: 32rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;

		.biaoti {
			font-size: 44rpx;
			color: #333;
			font-weight: bold;
		}

	}
	.sanjiaoxing {
		z-index: 100;
		position: absolute;
		top: 50rpx;
		right: 0rpx;
		width: 0;
		height: 0;
		border-left: 40rpx solid transparent;
		border-right: 40rpx solid transparent;
		border-bottom: 60rpx solid #4C4C4C;
	}
	.leftMenu {
		width: 380rpx;
		border-radius: 10rpx;
		position: absolute;
		top: 80rpx;
		right: 0;
		color: #fff;

		image {
			padding: 0 28rpx;
		}

		background: #4C4C4C;

		.items {
			display: flex;
			align-items: center;
			padding: 40rpx 0rpx;
			border-bottom: 1rpx solid #666666;
		}

		.items:nth-child(4) {
			border-bottom: 0rpx solid #666666;
		}
	}

	page {
		height: 100%;
	}

	.conversations {
		background: #fff;
		width: 750rpx;
		overflow-x: hidden;
		display: flex;
		flex-direction: column;
		box-sizing: border-box;
		height: 100%;
	}

	.conversations .scroll-item {
		height: 152rpx;
		display: flex;
		align-items: center;
		padding-left: 32rpx;
		border-bottom: 1px solid #EFEFEF;
	}

	.conversations .scroll-item .head-icon {
		width: 100rpx;
		height: 100rpx;
		margin-right: 28rpx;
	}

	.conversations .scroll-item_info {
		height: 151rpx;
		width: 590rpx;
		padding-right: 32rpx;
		box-sizing: border-box;
		// border-bottom: 1px solid #EFEFEF;
	}

	.conversations .scroll-item_info .item-info-top {
		padding-top: 20rpx;
		height: 60rpx;
		line-height: 60rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;

	}

	.conversations .item-info-top_name {
		font-size: 34rpx;
		font-weight: bold;
		color: #262628;
	}

	.conversations .item-info-top_time {
		font-size: 26rpx;
		color: rgba(179, 179, 179, 0.8);
		font-family: Source Han Sans CN;
	}

	.conversations .item-info-bottom {
		height: 40rpx;
		line-height: 40rpx;
		overflow: hidden;
	}

	.conversations .item-info-bottom-item {
		display: flex;
		justify-content: space-between;
	}

	.item-info-bottom .item-info-top_content {
		font-size: 30rpx;
		color: #b3b3b3;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;

	}

	.item-info-bottom .item-info-bottom_action {
		width: 50rpx;
		height: 50rpx;
		font-size: 20rpx;
		background: url("../../../static/comm-images/action.png") no-repeat center;
		background-size: 28rpx 30rpx;
	}

	.no-conversation {
		width: 100%;
		text-align: center;
		height: 80rpx;
		line-height: 80rpx;
		font-size: 28rpx;
		color: #9D9D9D;
	}

	.item-head {
		position: relative;
	}

	.item-head .item-head_unread {
		padding: 6rpx;
		background-color: #EE593C;
		color: #FFFFFF;
		font-size: 24rpx;
		line-height: 28rpx;
		border-radius: 24rpx;
		min-width: 24rpx;
		min-height: 24rpx;
		text-align: center;
		position: absolute;
		top: 0;
		right: 15rpx;
	}

	.action-container {
		width: 100%;
		height: 100%;
		position: absolute;
		top: 0;
		left: 0;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.action-container .layer {
		position: absolute;
		top: 0;
		left: 0;
		background: rgba(51, 51, 51, 0.5);
		width: 100%;
		height: 100%;
		z-index: 99;
	}

	.action-box {
		width: 620rpx;
		height: 280rpx;
		background: #ffffff;
		position: relative;
		z-index: 100;
		border-radius: 20rpx;
		overflow: hidden;
	}

	.action-item {
		text-align: left;
		padding-left: 40rpx;
		line-height: 140rpx;
		font-size: 34rpx;
		color: #262628;
		border-bottom: 1px solid #EFEFEF;

	}
</style>
