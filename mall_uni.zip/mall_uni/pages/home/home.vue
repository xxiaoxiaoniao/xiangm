<template>
	<view style="background-color: white;">
		<swiper :indicator-dots="false" :autoplay="true" :interval="3000" :duration="200" circular>
			<swiper-item v-for="(item, index) in lunboItem"><image style="width: 100%; height: 100%;" :src="item.images" mode=""></image></swiper-item>
		</swiper>
		<view class="body">
			<view style="white-space: nowrap;border-radius: 30rpx;">
				<scroll-view scroll-x style="display: inline-block;  height: 300rpx; vertical-align: top;">
					<uni-grid :column="5" :showBorder="false">
						<uni-grid-item v-for="(item, index) in lunboItem1" :key="index">
							<view>
								<image style="width: 50rpx; height: 50rpx; margin-left: 35rpx; margin-top: 20rpx;" :src="item.images" mode=""></image>
								<view style="width: 40rpx;height: 40rpx;">{{ item.title }}</view>
							</view>
						</uni-grid-item>
					</uni-grid>
				</scroll-view>
			</view>

			<view style="width: 700rpx; height: 440rpx;background-color: white;" class="clearfix">
				<view style="float: left;width: 294rpx;height: 420rpx; background-color:#FBF9F8;padding-top: 20rpx;">
					<view style="color: #FF6200;font-size: 36rpx; margin-left: 22rpx;">限时抢购</view>
					<text style="color:#6F6F6F;margin: 20rpx 25rpx; 10rpx 5rpx">距离结束</text>
					<uni-countdown
						style="display: inline-block;"
						:fontSize="10"
						:show-day="false"
						:hour="12"
						:minute="12"
						:second="12"
						background-color="#383838"
						color="#FFFFFF"
					></uni-countdown>
					
					<image style="width: 250rpx; height: 250rpx;margin:40rpx 20rpx; " src="/static/tp/6.png" mode=""></image>
				</view>
				<view style="float: right;width: 391rpx;height: 440rpx;">
					<navigator url="../shangpxqy/shangpxqy" open-type="navigate">
						<view style="width: 390rpx;height: 170rpx; background-color:#FBF9F8; padding-top: 20rpx;">
							<view style="width: 230rpx; height: 215; float: left; margin-left: 20rpx;">
								<view style="width:195rpx; height: 50rpx; font-size: 36rpx;">拼团专区</view>
								<text style="font-size:3rpx;color: gray;">想要的爆款都在这里</text>
							</view>
							<view style="width: 195rpx; height: 195; float:right; margin-top: -30rpx;">
								<image style="width: 120rpx; height: 120rpx;margin-left: 60rpx;margin-top: -60rpx;" src="/static/tp/tt1.png" mode=""></image>
							</view>
						</view>
					</navigator>
					<view style="width: 390rpx;height: 230rpx;margin-top: 16rpx; ">
						<view style="float: left;  width: 187rpx; height: 215rpx;padding-top: 20rpx;text-align: center;background-color: #FBF9F8; ">
							<view style="margin: 10rpx;">淘抢购</view>
							<image style="width: 120rpx; height: 120rpx;" src="/static/tp/5.png" mode=""></image>
						</view>
						<view style="float: right; width: 187rpx; height: 215rpx; padding-top: 20rpx; text-align: center;background-color: #FBF9F8;">
							<view style="margin: 10rpx;">聚划算</view>
							<image style="width: 120rpx; height: 120rpx;" src="/static/tp/3.png" mode=""></image>
						</view>
					</view>
				</view>

				<view
					style="background-image: url(/static/tp/biaotizhuangshi@2x.png); background-repeat: no-repeat;  background-size:250rpx 20rpx;width: 300rpx; float: left;line-height: 20rpx; margin: 50rpx 0 50rpx 200rpx ; "
				>
					<text style="margin:0 0 20rpx 55rpx;font-size: 36rpx;font-weight: 700;">精选好物</text>
				</view>
				<view class="swiper-container" style="margin-top: 20rpx;">
					<view class="swiper-container__box">
						<scroll-view scroll-x>
							<block v-for="(item, index) in jdItems">
								<view style="width: 250rpx; height: 350rpx;margin:10rpx; background-color: white; " class="image-box">
									<image style="width: 200rpx; height: 200rpx;" :src="item.images" mode=""></image>
									<view class="gridItem1" style="font-size: 20rpx;">{{ item.title }}</view>
									<text style="color: red;">￥{{ item.price }}</text>
									<text style="color: #666; text-decoration:line-through;">￥{{ item.price1 }}</text>
								</view>
							</block>
						</scroll-view>
					</view>
				</view>

				<view
					style="background-image: url(/static/tp/biaotizhuangshi@2x.png); background-repeat: no-repeat;  background-size:250rpx 20rpx;width: 300rpx; float: left;line-height: 20rpx; margin: 50rpx 0 50rpx 200rpx ; "
				>
					<text style="margin:0 0 20rpx 55rpx;font-size: 36rpx;font-weight: 700;">活动专区</text>
				</view>
			</view>
		</view>
		<uni-grid :column="2" :showBorder="false" :square="false" :highlight="false" style="margin-top: -100rpx;">
			<uni-grid-item v-for="(item, index) in goodsList" :key="index">
				<view class="cell" :style="{ marginLeft: index % 2 == 0 ? '10rpx' : '5rpx' }">
					<image :src="item.imgSrc" mode=""></image>
					<view style="background-color: white;margin-top: -20rpx;">
						<view>{{ item.goodsName }}</view>
						<view>{{ item.shortBrief }}</view>
						<view>{{ item.details }}</view>
						<view style="display: inline-block;">¥{{ item.price }}</view>
						<navigator style="display: inline-block;" url="../shangpinxiangqing/shangpinxiangqing">
							<image style="width: 50rpx; height: 50rpx;margin-left: 150rpx;" :src="item.images1" mode=""></image>
						</navigator>
					</view>
				</view>
			</uni-grid-item>
		</uni-grid>
		<uni-load-more :status="status"></uni-load-more>
	</view>
</template>

<script>
export default {
	data() {
		return {
			status: 'more',
			goodsList: [],
			jdItems: [],
			lunboItem1: [
				{ images: '/static/tp/nvzhuang@3x.png', title: '女神服饰' },
				{ images: '/static/tp/xiebao@2x.png', title: '鞋包配饰' },
				{ images: '/static/tp/muyin@2x.png', title: '母婴宝贝' },
				{ images: '/static/tp/nanzhuang@2x.png', title: '品质男装' },
				{ images: '/static/tp/letao@2x.png', title: '海外乐淘' },
				{ images: '/static/tp/hufu@2x.png', title: '化妆护肤' },
				{ images: '/static/tp/shoushi@2x.png', title: '珠宝首饰' },
				{ images: '/static/tp/shenghuoyongpin@2x.png', title: '生活用品' },
				{ images: '/static/tp/chaoshi@2x.png', title: '商城超市' },
				{ images: '/static/tp/gengduo@2x.png', title: '更多商品' }
			],
			lunboItem: [
				{ images: '/static/tp/beijin@3x.png' },
				{ images: '/static/tp/beijin@3x.png' },
				{ images: '/static/tp/beijin@3x.png' },
				{ images: '/static/tp/beijin@3x.png' }
			],
			page:1,//起始页
			limit:10//每页多少条
		};
	},
	onPullDownRefresh() { 
		console.log("我也被触发了")
	},
	onReachBottom() {
		console.log('我被触发了')
		this.goods();
	},
	onShow() {
		this.goods()
	},
	methods: {
		goods(){
			 //请求的代码 调用
			 this.api.goods({
				 page:this.page,
				 limit:this.limit
			 }).then((res) => {
			 	if(res.flag){
					if(res.data.length <= 0){
						return;
					}
					this.page = this.page+1;
			 		let data = res.data;
			 		for(let i = 0;i<data.length;i++){
			 			data[i].imgSrc = data[i].imgSrc.split(",")[0];
			 		}
			 		this.goodsList = data;
					this.jdItems = data;
			 	}
			 }).catch((res) =>{ });
		},
	
		goDtial(){
			this.uni.navigateTo({
				url: '../shangpxqy/shangpxqy',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style lang="scss">
.cell {
	width: 360rpx;
	border: 1px solid #f8f8f8;
	//box-shadow: 0 0 1px #F8F8F8;
	border-radius: 8rpx;
	margin-top: 10rpx;

	image {
		width: 100%;
		height: 260rpx;
	}

	> view {
		padding: 10rpx;

		> view {
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;

			&:first-of-type {
				font-size: 0.9em;
			}

			&:nth-of-type(2) {
				font-size: 0.7em;
				color: gray;
				margin: 8rpx 0;
			}

			&:nth-of-type(3) {
				color: red;
			}
		}
	}
}
.swiper-container {
	.swiper-container__box {
		box-sizing: border-box;
		// border:1px solid red;
		width: 100%;
		white-space: nowrap; // 横向滚动必要属性
		.image-box {
			display: inline-block; // 图片的外层定义成行内元素才可进行滚动
			width: 100px;
			height: 100px;
			// border:1px solid green;
			image {
				width: 100%;
				height: 100%;
			}
		}
	}
	// block 是必须定义的外层元素,否则无法进行横向滚动
}
.clearfix:after {
	/*伪元素是行内元素 正常浏览器清除浮动方法*/
	content: '';
	display: block;
	height: 0;
	clear: both;
	visibility: hidden;
}
.body {
	margin: 0 auto;
	width: 700rpx;
	height: 1400rpx;
	background-color: #f7f7f7;
}
.gridItem1 {
	overflow: hidden;
	text-overflow: ellipsis;
	display: -webkit-box;
	-webkit-line-clamp: 2; //多行在这里修改数字即可
	-webkit-box-orient: vertical;
}
</style>
