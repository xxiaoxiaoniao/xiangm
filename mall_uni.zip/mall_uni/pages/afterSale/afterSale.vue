<template>
	<view>
		<view style="width: 750rpx; height: 900rpx;">
			<uni-segmented-control
				:current="current"
				:values="items"
				@clickItem="onClickItem"
				activeColor="#E95656"
				styleType="text"
				style="width: 750rpx;background-color: white;height: 100rpx;border-top: 1rpx solid #EEEEEE;"
			></uni-segmented-control>
			<view class="content" style="width:700rpx;height: 400rpx; margin: 30rpx auto;">
				<view v-for="(item, index) in 9" v-show="current === 0">
					<view style="width:700rpx;height: 400rpx;background-color: white; margin: 30rpx auto;border-radius: 20rpx;">
						<view style="width: 640rpx; height: 480rpx;margin: 0 auto; display: flex;align-items: center;">
							<view style="width: 640rpx; height: 460rpx;">
								<view style="width: 640rpx; height:60rpx; background-color: white; display: flex;justify-content: space-between;">
									<text style="color: #999999;">订单号：</text>
									<text style="color: #999999;">0145826985357859</text>
								</view>
								<view style="width: 640rpx; height:60rpx; background-color: white; display: flex;justify-content: space-between;">
									<text style="color: #999999;">下单时间：</text>
									<text style="color: #999999;">2022-2-20 19:30:06</text>
								</view>
								<view style="width: 640rpx; height: 200rpx;display: flex;">
									<view style="width: 250rpx; height: 260rpx;display: flex;justify-content: center;align-items: center;">
										<image style="width: 200rpx; height: 200rpx;" src="/static/tp/zhuce/chanpintu@3x.png" mode=""></image>
									</view>

									<view style="width: 390rpx; height: 260rpx;">
										<view style="width: 390rpx;height: 88rpx;font-size: 30rpx;" class="xianshi">
											先理解什么是开源，一句话来说，开源指的是那些源代码或源设计可以被大众使用、修改发行的软件或设计体。
										</view>
										<view style="font-size: 20rpx; color: #999999;height: 60rpx;line-height: 60rpx;">Macvic2专业版+配件包+随心换</view>
										<view style="width: 390rpx; height: 80rpx;display: flex;">
											<view style="width: 195rpx;height: 80rpx; line-height: 100rpx;">
												<text style="font-weight: bold;color: #FF5907;">￥13186</text>
												<text style="margin: 0 20rpx;">x1</text>
											</view>
											<view style="width: 195rpx;height: 80rpx; line-height: 80rpx;">
												<button type="default" size="mini" style="border-radius: 30rpx;margin: 0 0 0 20rpx;vertical-align: middle;" @click="show = true">
													申请退款
												</button>
											</view>
										</view>
									</view>
								</view>
							</view>
						</view>
					</view>
				</view>
				<view v-for="(item, index) in 9" v-show="current === 1">
					<view style="width:700rpx;height: 630rpx;background-color: white; margin: 30rpx auto;border-radius: 20rpx;">
						<view style="width: 640rpx; height: 630rpx;margin: 0 auto; display: flex;align-items: center;">
							<view style="width: 640rpx; height: 630rpx;">
								<view
									style="width: 640rpx; height:100rpx; background-color: white; display: flex;justify-content: space-between; border-bottom: 1rpx solid #EDEDED;align-items: center;"
								>
									<text style="color: #999999;">退款单号：</text>
									<text style="color: #999999;">0145826985357859</text>
								</view>
								<view
									style="width: 640rpx; height:150rpx; background-color: white; display: flex;justify-content: space-between; background-color: #F5F5F5;border-radius: 15rpx; margin: 20rpx auto; align-items: center;"
								>
									<view style="width: 640rpx; height: 120rpx;display: flex;">
										<view style="width: 540rpx;height: 120rpx; line-height: 55rpx;padding: 0 0 0 10rpx;">
											<view>提交申请</view>
											<view style="font-size: 30rpx;color: #999999;">您的退款已申请成功，待客服审核中</view>
										</view>
										<view style="width: 100rpx; height: 120rpx;display: flex;justify-content:flex-end; align-items: center;">
											<image style="width: 20rpx; height: 30rpx; margin: 0 20rpx;" src="/static/tp/zhuce/gengduo@2x.png" mode=""></image>
										</view>
									</view>
								</view>
								<view style="width: 640rpx;display: flex;">
									<view style="width: 250rpx; height: 260rpx;display: flex;justify-content: center;align-items: center;">
										<image style="width: 200rpx; height: 200rpx;" src="/static/tp/zhuce/chanpintu@3x.png" mode=""></image>
									</view>

									<view style="width: 390rpx; height: 260rpx;">
										<view style="width: 390rpx;height: 88rpx;font-size: 30rpx;" class="xianshi">
											先理解什么是开源，一句话来说，开源指的是那些源代码或源设计可以被大众使用、修改发行的软件或设计体。
										</view>
										<view style="font-size: 20rpx; color: #999999;height: 60rpx;line-height: 60rpx;">Macvic2专业版+配件包+随心换</view>
										<view style="width: 390rpx; height: 150rpx;">
											<view style="width: 195rpx;height: 80rpx; line-height: 100rpx;">
												<text style="font-weight: bold;color: #FF5907;">￥13186</text>
												<text style="margin: 0 20rpx;">x1</text>
											</view>
											<view style="width:390rpx;height: 80rpx; display: flex; justify-content: flex-end;">
												<view><button type="default" size="mini" style="border-radius: 30rpx;" @click="show =true">申请退款</button></view>
											</view>
										</view>
									</view>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
		<u-picker :show="show" ref="uPicker" :columns="columns" @confirm="confirm" @change="changeHandler"></u-picker>
	</view>
</template>

<script>
export default {
	data() {
		return {
			show:false,
			 columns: [
			                    ['中国', '美国'],
			                    ['深圳', '厦门', '上海', '拉萨']
							],
			                columnData: [
			                    ['深圳', '厦门', '上海', '拉萨'],
			                    ['得州', '华盛顿', '纽约', '阿拉斯加']
			                ],
			items: ['售后申请', '申请记录'],
			current: 0
		};
	},
	methods: {
		  changeHandler(e) {
		                const {
		                    columnIndex,
		                    value,
		                    values, // values为当前变化列的数组内容
		                    index,
							// 微信小程序无法将picker实例传出来，只能通过ref操作
		                    picker = this.$refs.uPicker
		                } = e
		                // 当第一列值发生变化时，变化第二列(后一列)对应的选项
		                if (columnIndex === 0) {
		                    // picker为选择器this实例，变化第二列对应的选项
		                    picker.setColumnValues(1, this.columnData[index])
		                }
		            },
					// 回调参数为包含columnIndex、value、values
					confirm(e) {
		                console.log('confirm', e)
		                this.show = false
					},
		onClickItem(e) {
			if (this.current != e.currentIndex) {
				this.current = e.currentIndex;
			}
		}
	}
};
</script>

<style>
.xianshi {
	overflow: hidden;
	text-overflow: ellipsis;
	display: -webkit-box;
	-webkit-line-clamp: 2;
	-webkit-box-orient: vertical;
	display: -moz-box;
	-moz-line-clamp: 2;
	-moz-box-orient: vertical;
	word-wrap: break-word;
	word-break: break-all;
	white-space: normal;
}
</style>
