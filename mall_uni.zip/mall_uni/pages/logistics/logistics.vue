<template>
	<view style="width: 750rpx; ">
		<view style="width: 700rpx;height: 1100rpx;margin: 30rpx auto;">
			<view style="width:700rpx;height: 300rpx; background-color: white; border-radius: 20rpx; display: flex;align-items: center;">
				<view style="width: 250rpx; height: 230rpx; display: flex;justify-content: center;align-items: center;">
					<image style="width: 230rpx;height: 230rpx;" src="/static/tp/zhuce/chanpintu@3x.png" mode=""></image>
				</view>
				<view style="width: 450rpx; height: 230rpx;">
					<view style="font-size: 28rpx;font-weight: bold; color: #333333;">DJI大疆无人机新款六期免息Mavice2Probably选专业无人机版可折叠航拍首选</view>
					<view style="color: #999999;font-size: 25rpx; margin: 20rpx 0;">运单号:016758469253684</view>
					<view style="color: #999999;font-size: 25rpx;">物流:中通速递</view>
				</view>
			</view>
			<view style="width: 100%;height: 750rpx; background-color: white; margin: 30rpx auto;border-radius: 20rpx;">
				<view style="width: 700rpx; margin: 0 40rpx;">
					<view style="width: 700rpx; height: 100rpx;line-height: 100rpx; font-weight: bold;font-size: 35rpx;">物流信息</view>
					<view><uni-steps :options="options" direction="column" :active="active"></uni-steps></view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			active:3,
			options: [
				{ title: '买家下单', desc: '2018-11-11' },
				{ title: '卖家发货', desc: '2018-11-12' },
				{ title: '买家签收', desc: '2018-11-13' },
				{ title: '交易完成', desc: '2018-11-14' },
				{ title: '买家下单', desc: '2018-11-11' },
				{ title: '卖家发货', desc: '2018-11-12' },
				
			]
		};
	},
	methods: {}
};
</script>

<style></style>
