<template>
	<view>
		<view style="width: 100%; height: 500rpx; background-image: url(/static/shangpxqy/beijingtu.png); position: relative;">
			<view style="width: 700rpx; height: 100rpx;margin: 0 auto;position: absolute;top:20%;left: 4%;">
				<uni-easyinput
					:inputBorder="false"
					prefixIcon="search"
					type="text"
					value=""
					placeholder="请输入商品名称/类型"
					style="background-color: white; width: 600rpx; height: 70rpx;border-radius: 50rpx; display: inline-block; vertical-align: middle;"
				></uni-easyinput>
				<image style="width: 60rpx; height: 60rpx;vertical-align: middle; margin: 0 20rpx;" src="/static/shangpxqy/gouwuche.png" mode=""></image>
				<view style="width: 700rpx;height: 100rpx;line-height: 100rpx;background-color: #606266;">快速导航</view>
				<view>
					<uni-grid :column="5" :showBorder="false">
						<uni-grid-item v-for="(item, index) in lunboItem1" :key="index">
							
								<!-- <image style="width: 130rpx; height: 130rpx; margin: 10rpx;" :src="item.images" mode=""></image> -->
							<!-- 	<view style="width: 100rpx; height: 100rpx;background-image: url('/static/shangpxqy/item.images'+.png);">
									<text>{{ item.title }}</text>
								</view> -->
								
							
						</uni-grid-item>
					</uni-grid>
				</view>
			</view>
			
		</view>
		<view>
			
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			lunboItem1: [
				{ images: '/static/shangpxqy/xinxi.png', title: '消息' },
				{ images: '/static/shangpxqy/shouye.png', title: '首页' },
				{ images: '/static/shangpxqy/fenlei.png', title: '分类' },
				{ images: '/static/shangpxqy/guanzhu.png', title: '关注' },
				{ images: '/static/shangpxqy/fankui.png', title: '反馈' },
			],
		};
	},
	methods: {}
};
</script>

<style></style>
