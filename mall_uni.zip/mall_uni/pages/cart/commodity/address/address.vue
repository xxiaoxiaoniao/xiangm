<template>
	<view>
		<view class="aa1">
			<view style="width: 670rpx; height: 700rpx;">
				<view style="width: 670rpx; height: 100rpx; display: flex;align-items: center;">
					<view style="width: 130rpx; height: 100rpx; line-height: 100rpx;color: #333333;">联系人</view>
					<view style="width: 540rpx;height: 100rpx; border-bottom: 1rpx solid #F2F2F2; display: flex;align-items: center;">
						<u--input placeholder="收件人" border="none" type="text"></u--input>
						<image style="width: 50rpx;height: 50rpx;" src="/static/denglu/tongxunlu@2x.png" mode=""></image>
					</view>
				</view>
				<view style="width: 670rpx; height: 150rpx; display: flex;align-items: center;">
					<view style="width: 160rpx; height: 150rpx; line-height: 150rpx;color: #333333;">联系电话</view>
					<view style="width: 540rpx;height: 150rpx; border-bottom: 1rpx solid #F2F2F2; display: flex;align-items: center;">
						<u--input placeholder="联系电话" border="none" type="number"></u--input>
						<!-- <image style="width: 50rpx;height: 50rpx;" src="/static/denglu/tongxunlu@2x.png" mode=""></image> -->
					</view>
				</view>
				<view style="width: 670rpx; height: 150rpx; display: flex;align-items: center;">
					<view style="width: 160rpx; height: 150rpx; line-height: 150rpx;color: #333333;">选择地区</view>
					<view style="width: 540rpx;height: 150rpx; border-bottom: 1rpx solid #F2F2F2; display: flex;align-items: center;justify-content: space-between;">
						<view @click="open"><u--input placeholder="省 市 区 乡镇/街道" border="none" type="number"></u--input></view>
						<image @click="showModal" style="width: 40rpx;height: 50rpx;" src="/static/denglu/dingwei@2x.png" mode=""></image>
					</view>
				</view>
				<view style="width: 670rpx; height: 150rpx; display: flex;align-items: center;">
					<view style="width: 160rpx; height: 150rpx; line-height: 150rpx;color: #333333;">详细地址</view>
					<view style="width: 540rpx;height: 150rpx; border-bottom: 1rpx solid #F2F2F2; display: flex;align-items: center;">
						<u--input placeholder="街道门牌信息" border="none" type="number"></u--input>
						<!-- <image style="width: 40rpx;height: 50rpx;" src="/static/denglu/dingwei@2x.png" mode=""></image> -->
					</view>
				</view>
				<view style="width: 670rpx; height: 150rpx; display: flex;align-items: center;">
					<view style="width: 160rpx; height: 150rpx; line-height: 150rpx;color: #333333;">邮政编码</view>
					<view style="width: 540rpx;height: 150rpx;display: flex;align-items: center;">
						<u--input placeholder="邮政编码" border="none" type="number"></u--input>
						<!-- <image style="width: 40rpx;height: 50rpx;" src="/static/denglu/dingwei@2x.png" mode=""></image> -->
					</view>
				</view>
			</view>
		</view>
		<view style="width: 700rpx; height: 100rpx; margin: 30rpx auto;background-color: white;border-radius: 20rpx;">
			<view style="width: 670rpx;height: 100rpx;margin: 0 auto;display: flex;justify-content: space-between;align-items: center;">
				<text style="color: #333333;">设为默认地址</text>
				<image style="width: 40rpx;height: 40rpx;" src="/static/denglu/shezhi@2x.png" mode=""></image>
			</view>
		</view>
		<view style="width: 750rpx;height: 400rpx;display: flex;align-items: center; justify-content: center;" @click="login()"><view class="chuceanniu">保存</view></view>
		<uni-popup ref="popup" typeOptions="bottom" backgroundColor="#fff">
			<view style="width: 750rpx; height: 800rpx;">
				<view style="width: 700rpx; height: 800rpx; margin: 0 auto;">
					<view style="display: flex;justify-content: flex-end;">
						<view style="width:450rpx; height: 150rpx;display: flex;justify-content: space-between;align-items: center; ">
							<text style="font-size: 35rpx;font-weight: bold;">配送至</text>
							<image @click="close" style="width: 35rpx; height: 35rpx;vertical-align: middle; margin: 0 20rpx;" src="/static/denglu/quxiao@2x.png" mode=""></image>
						</view>
					</view>

					<!-- <view style="width: 700rpx; height: 100rpx;display: flex;align-items:center;border-bottom: 1rpx solid #F2F2F2;">
						<image style="width: 35rpx; height: 35rpx;vertical-align: middle; margin: 0 20rpx;" src="/static/denglu/gouxuan@2x.png" mode=""></image>
						<text>广东省广州市天河区珠江新城128号</text>
					</view>
					<view style="width: 700rpx; height: 100rpx;display: flex;align-items: center;border-bottom: 1rpx solid #F2F2F2;">
						<image style="width: 35rpx; height: 35rpx;vertical-align: middle; margin: 0 20rpx;" src="/static/denglu/weigouxuan@2x.png" mode=""></image>
						<text>广东省广州市海珠区小洲村18号</text>
					</view> -->
					<view style="width: 700rpx; height: 390rpx;display: flex;align-items: flex-end;">
						<view style="width: 700rpx; height: 100rpx;margin: 50rpx auto;">
							<view style="width: 700rpx;height: 100rpx;display: flex;align-items: center; justify-content: center;">
								<view class="chuceanniu">选择其它地址</view>
							</view>
						</view>
					</view>
				</view>
			</view>
		</uni-popup>
		<u-modal :show="show"  :showConfirmButton="false" :zoom="true">
			<view style="width: 700rpx; height: 600rpx; background-image: url(/static/denglu/juxing.png);background-size: 570rpx;background-repeat: no-repeat;display: flex;align-items: flex-end;">
				<view style="width: 550rpx; height: 300rpx;display: flex;justify-content: center;">
					<view style="width: 550rpx;height: 300rpx;">
						<view style="width: 550rpx; height: 100rpx; text-align: center; line-height: 100rpx;font-size: 40rpx;">定位系统未开启</view>
						<view style="width: 550rpx; height: 90rpx; text-align: center;color: #999999;">开启定位系统可获得更精准位置</view>
						<view style="width: 550rpx;height: 120rpx;text-align: center;line-height: 120rpx;color: white;font-size: 35rpx;">立即开启</view>
					</view>
					<view @click="confirm" style="width: 550rpx; height: 100rpx;position: fixed; bottom: 200rpx;text-align: center;">
						<image style="width: 50rpx;height: 50rpx;" src="/static/denglu/quxiao@2x2.png" mode=""></image>
					</view>
				</view>
			</view>
		</u-modal>
	</view>
</template>

<script>
export default {
	data() {
		return {
			show: false
		};
	},
	methods: {
		open() {
			this.$refs.popup.open('bottom');
		},
		close() {
			this.$refs.popup.close();
		},
		showModal() {
			this.show = true;
		},
		confirm() {
			
				// 3秒后自动关闭
				this.show = false;
			
		}
	}
};
</script>

<style>
.chuceanniu {
	background-size: 650rpx;
	color: white;
	display: flex;
	justify-content: center;
	align-items: center;
	width: 650rpx;
	height: 100rpx;
	background-image: url(/static/denglu/anniu121.png);
	background-repeat: no-repeat;
}
.aa1 {
	width: 700rpx;
	height: 700rpx;
	margin: 30rpx auto;
	background-color: white;
	border-radius: 20rpx;
	display: flex;
	justify-content: center;
	align-items: center;
}
</style>
