<template>
	<view>
		<view class="u-demo-block">
			<u-swiper :list="list6" height="300" :autoplay="false" indicatorStyle="right: 20px">
				<view slot="indicator" class="indicator-num"><!-- <text class="indicator-num__text">{{ currentNum + 1 }}/{{ list6.length }}</text> --></view>
			</u-swiper>
		</view>
		<view style="width: 750rpx; background-color: white; border-radius: 20rpx;">
			<view style="width: 700rpx;height: 300rpx;margin: 0 auto;">
				<view style="display: flex;justify-content: space-between;background-color: white;align-items: center;margin: 10rpx auto;">
					<view>
						<text style="color:#FF5907;font-size: 20rpx;">￥</text>
						<text style="color:#FF5907;font-size: 35rpx;font-weight: bold;">13186</text>
					</view>
					<view style="width: 200rpx; height: 80rpx;">
						<view style="display: flex; justify-content: space-between;align-items: center;">
							<view style="width: 105rpx;height: 80rpx;background-color: white;text-align: center;">
								<image style="width: 30rpx;height: 30rpx;" src="/static/denglu/jiangjia@2x.png" mode=""></image>
								<view style="font-size: 20rpx;color: #666666;">降价通知</view>
							</view>
							<view style="width: 105rpx;height: 80rpx;background-color: white;text-align: center;">
								<image style="width: 30rpx;height: 30rpx;" src="/static/denglu/guanzhu@2x.png" mode=""></image>
								<view style="font-size: 20rpx;color: #666666;">关注</view>
							</view>
						</view>
					</view>
				</view>
				<view
					style=" margin: 10rpx auto; width: 650rpx; height: 60rpx;background-color: #F7F8F9; margin: 0 auto; display: flex;justify-content: space-between;align-items:center;"
				>
					<view>
						<image style="width: 30rpx; height: 30rpx;margin: 0 10rpx;vertical-align: middle;" src="/static/denglu/huiyuan@2x.png" mode=""></image>
						<text style="font-size: 5rpx;color: #999999;">新人首单购买可直升黄金会员解锁更多权益</text>
					</view>
					<image style="width: 10rpx; height: 15rpx; margin: 0 10rpx;" src="/static/denglu/gengduo@2x.png" mode=""></image>
				</view>
				<view style="width: 100%;height:100rpx;margin: 10rpx auto;">
					<text style="background-color:#FF5821;font-size: 20rpx;color: white;padding:0 15rpx; border-radius: 50rpx;">直营</text>
					<text style="font-size: 30rpx;color: #333333;vertical-align: middle;">婴幼儿宝宝触摸认知双语 会说话的早教启蒙有声（巴赫/维瓦尔第/莫扎特/贝多芬）套装全4册</text>
				</view>
			</view>
		</view>
		<view style="width: 750rpx;background-color:white;height: 180rpx; display: flex;justify-content: center;align-items: center;margin: 15rpx auto;">
			<view style="width: 700rpx;height: 160rpx;">
				<view style="width: 700rpx; height: 80rpx; display: flex;justify-content:space-between;align-items: center;">
					<view>
						<text style="color: #999999;">促销</text>
						<text style="margin: 0 30rpx;color:#E75E5A;background-color: #FFE9E9;font-size: 26rpx;padding: 5 10rpx; border-radius: 5rpx;">跨店铺满减</text>
						<text style="color:#3B4144;font-size: 30rpx;">满5000减50</text>
					</view>
					<view><image style="width: 40rpx; height:8rpx;" src="/static/denglu/qiehuan@2x.png" mode=""></image></view>
				</view>
				<view style="width: 700rpx; height: 80rpx;line-height: 80rpx;">
					<text style="margin: 0 20rpx 0 90rpx;color:#E75E5A;background-color: #FFE9E9;font-size: 26rpx; border-radius: 5rpx;">满折</text>
					<text style="font-size: 30rpx; color: #3A3A3A;">同一件商品,第二件享95折</text>
				</view>
			</view>
		</view>
		<view style="width: 750rpx;height: 200rpx; background-color: white;">
			<view style="width: 680rpx; height: 180rpx;">
				<view style="width: 750rpx; height: 180rpx;">
					<view style="width: 700rpx; height: 180rpx;display: flex;align-items: center;justify-content:space-around;margin: 0 auto;">
						<view style=" width: 100rpx; height: 100rpx; text-align: center;">
							<image style="width: 50rpx; height: 50rpx;" src="/static/mipmap-hdpi/kefu.png" mode=""></image>
							<view style="color: #666666 ;">客服</view>
						</view>
						<view style=" width: 100rpx; height: 100rpx;text-align: center;">
							<image style="width: 50rpx; height: 50rpx;" src="/static/mipmap-hdpi/gouwuche2.png" mode=""></image>
							<view style="color: #666666 ;">购物车</view>
						</view>
						<view class="ss1" @click="open">
							<text style="width: 100%; height: 100rpx;display: flex;align-items: center;justify-content: center; color: white;">立即购买</text>
						</view>
						<view class="ss2"><text style="width: 100%; height: 100rpx;display: flex;align-items: center;justify-content: center;color: white;">加入购物车</text></view>
					</view>
				</view>
			</view>
		</view>
		<uni-popup ref="popup" typeOptions="bottom" backgroundColor="#fff">
			<view style="width: 750rpx; height: 800rpx; background-color: white;border-radius: 30rpx;">
				<view style="width: 700rpx; height: 800rpx; margin: 0 auto;">
					<view style="display: flex;justify-content: flex-end;">
						<view style="width:450rpx; height: 150rpx;display: flex;justify-content: space-between;align-items: center; ">
							<text style="font-size: 35rpx;font-weight: bold;">配送至</text>
							<image @click="close" style="width: 35rpx; height: 35rpx;vertical-align: middle; margin: 0 20rpx;" src="/static/denglu/quxiao@2x.png" mode=""></image>
						</view>
					</view>
					<view style="width: 700rpx; height: 100rpx;display: flex;align-items:center;border-bottom: 1rpx solid #F2F2F2;">
						<image style="width: 35rpx; height: 35rpx;vertical-align: middle; margin: 0 20rpx;" src="/static/denglu/gouxuan@2x.png" mode=""></image>
						<text>广东省广州市天河区珠江新城128号</text>
					</view>
					<view style="width: 700rpx; height: 100rpx;display: flex;align-items: center;border-bottom: 1rpx solid #F2F2F2;">
						<image style="width: 35rpx; height: 35rpx;vertical-align: middle; margin: 0 20rpx;" src="/static/denglu/weigouxuan@2x.png" mode=""></image>
						<text>广东省广州市海珠区小洲村18号</text>
					</view>
					<view style="width: 700rpx; height: 390rpx;display: flex;align-items: flex-end;">
						<view style="width: 700rpx; height: 100rpx;margin: 50rpx auto;">
							<view style="width: 700rpx;height: 100rpx;display: flex;align-items: center; justify-content: center;">
								<navigator url="address/address">
								<view class="chuceanniu">选择其它地址</view>
								</navigator>
							</view>
						</view>
					</view>
				</view>
			</view>
		</uni-popup>
	</view>
</template>

<script>
export default {
	data() {
		return {
			list6: ['https://cdn.uviewui.com/uview/swiper/swiper2.png', 'https://cdn.uviewui.com/uview/swiper/swiper3.png', 'https://cdn.uviewui.com/uview/swiper/swiper1.png']
		};
	},
	methods: {
		open() {
			this.$refs.popup.open('bottom');
		},
		close() {
			this.$refs.popup.close();
		}
	}
};
</script>

<style lang="scss">
.chuceanniu {
	background-size: 650rpx;
	color: white;
	display: flex;
	justify-content: center;
	align-items: center;
	width: 650rpx;
	height: 100rpx;
	background-image: url(/static/denglu/anniu121.png);
	background-repeat: no-repeat;
}
.ss2 {
	background-image: url(/static/mipmap-hdpi/gouwu.png);
	background-repeat: no-repeat;
	background-size: 200rpx 90rpx;
	width: 200rpx;
	height: 100rpx;
	float: right;
}
.ss1 {
	background-image: url(/static/mipmap-hdpi/goumai.png);
	background-repeat: no-repeat;
	background-size: 200rpx 90rpx;
	width: 200rpx;
	height: 100rpx;
	float: right;
}
.indicator {
	@include flex(row);
	justify-content: center;

	&__dot {
		height: 6px;
		width: 6px;
		border-radius: 100px;
		background-color: rgba(255, 255, 255, 0.35);
		margin: 0 5px;
		transition: background-color 0.3s;

		&--active {
			background-color: #ffffff;
		}
	}
}

.indicator-num {
	padding: 2px 0;
	background-color: rgba(0, 0, 0, 0.35);
	border-radius: 100px;
	width: 35px;
	@include flex;
	justify-content: center;

	&__text {
		color: #ffffff;
		font-size: 12px;
	}
}
</style>
