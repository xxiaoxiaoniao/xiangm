<template>
	<view class="ss7">
		<view style="width:700rpx;height:90rpx;line-height: 70rpx;margin: 0 auto; padding-top: 20rpx;">
			<navigator url="../home/home" style="display: inline-block;">
				<image style="width: 20rpx; height: 30rpx;vertical-align: middle;" src="/static/mipmap-hdpi/fanhui.png" mode=""></image>
			</navigator>
			<text class="ss8">商品</text>
			<text style="font-weight: 600;color: white;font-size: 30rpx;padding:0 30rpx;">详情</text>
			<text style="font-weight: 600;color: white;font-size: 30rpx;padding:0 30rpx;">评价</text>
			<image style="width: 40rpx; height: 40rpx; margin: 0 30rpx 0 80rpx;vertical-align: middle;" src="/static/mipmap-hdpi/fenxiang.png" mode=""></image>
			<image style="width: 50rpx; height: 20rpx;" src="/static/mipmap-hdpi/gengduo2.png" mode=""></image>
		</view>
		<view style="width:100%; background-color: #FFFFFF; height: 270rpx; position: relative; ">
			<view style="width: 700rpx; height:80rpx;background-color:#F7F8F9;position: absolute;top: 10%;transform: translateY(-10%);margin-left: 25rpx;line-height: 80rpx;">
				<image style="width: 30rpx; height: 30rpx;vertical-align: middle; margin-left: 20rpx;" src="/static/mipmap-hdpi/huiyuan.png" mode=""></image>
				<text style="margin: 0 80rpx 0 15rpx;">新人首单购买可直升黄金会员解锁更多权益</text>
				<image style="width:15rpx; height:25rpx;vertical-align: middle;" src="/static/mipmap-hdpi/gengduo.png" mode=""></image>
			</view>
			<view style="width: 700rpx; height:150rpx;position: absolute;top: 56%;transform: translateY(-20%);margin-left: 50rpx;">
				<text style="background-color:#FF4B18;color: white; border-radius: 30rpx; padding: 0 10rpx; margin: 0 10rpx;">自营</text>
				<text style="font-size: 33rpx; font-weight: 700;">DJI 大疆无人机新款六期免息Mavic2Pro/zoomz专业无人机可折叠航拍选配带平遥</text>
			</view>
		</view>
		<view style="width:100%; background-color: #FFFFFF; height: 200rpx;margin: 20rpx auto;">
			<view style="width: 700rpx;height:100rpx;margin: 0 auto; line-height: 100rpx;">
				<text style="color:#999999;margin: 0 20rpx;">促销</text>
				<text style="background-color:#FFE9E9;color:#E75E5A;padding: 0 10rpx;border-radius: 5rpx; margin: 0 20rpx 0 5rpx;">跨店铺满减</text>
				<text style="color:#666666;">满5000减50</text>
				<image style="width: 50rpx; height: 10rpx; margin: 0 20rpx 0 170rpx;" src="/static/mipmap-hdpi/qiehuan.png" mode=""></image>
			</view>
			<view style="width: 700rpx;height:100rpx;margin: 0 auto; line-height: 100rpx;">
				<text style="background-color:#FFE9E9;color:#E75E5A;padding: 0 10rpx;border-radius: 5rpx; margin: 0 20rpx 0 100rpx;">满折</text>
				<text style="color:#666666;">同一件商品，第二件享95折</text>
			</view>
		</view>
		<view style="width:100%; background-color: #FFFFFF; line-height: 100rpx;">
			<view style="width:700rpx;height:100rpx;margin:0 auto;border-bottom: 1rpx solid #F2F2F2;">
				<text style="color:#999999;margin: 0 20rpx;">选择</text>
				<text style="color:#666666;">Macvic2专业版+配件包+随心换</text>
				<image style="width: 50rpx; height: 10rpx; margin: 0 20rpx 0 100rpx;" src="/static/mipmap-hdpi/qiehuan.png" mode=""></image>
			</view>
			<view style="width:700rpx;height:200rpx;margin:0 auto;border-bottom: 1rpx solid #F2F2F2;">
				<text style="color:#999999;margin: 0 20rpx;">配送</text>
				<text style="color:#666666;">广东省广州市天河区</text>
				<image style="width: 50rpx; height: 10rpx; margin: 0 20rpx 0 250rpx;" src="/static/mipmap-hdpi/qiehuan.png" mode=""></image>
				<view>
					<text style="margin: 0 20rpx 0 95rpx;color:#666666;">现货</text>
					<text style="color:#999999;">23:00前付款,预计明天(10月3日)前送到</text>
				</view>
			</view>
			<view style="width:700rpx;height:100rpx;margin:0 auto;border-bottom: 1rpx solid #F2F2F2;">
				<text style="color:#999999;margin: 0 20rpx;">运费</text>
				<text style="color:#666666;">包邮</text>
			</view>
			<view style="width:700rpx;height:100rpx;margin:0 auto;border-bottom: 1rpx solid #F2F2F2;">
				<text style="color:#999999;margin: 0 20rpx;">参数</text>
				<text style="color:#666666;">产品参数&包装清单</text>
			</view>
			<view style="width:700rpx;height:100rpx;margin:0 auto;border-bottom: 1rpx solid #F2F2F2;">
				<text style="color:#999999;margin: 0 20rpx;">服务</text>
				<image style="width: 30rpx; height: 30rpx; vertical-align: middle; margin: 0 10rpx 0 0;" src="/static/mipmap-hdpi/gouxuan.png" mode=""></image>
				<text style="vertical-align: middle;color:#999999;">货到付款</text>
				<image style="width: 30rpx; height: 30rpx;vertical-align: middle;margin: 0 10rpx 0 10rpx;" src="/static/mipmap-hdpi/gouxuan.png" mode=""></image>
				<text style="vertical-align: middle;color:#999999;">支持7天无理由退货</text>
			</view>
		</view>
		<view style="background-color: #FFFFFF;">
			<view style="width: 700rpx; height: 850rpx;margin: 30rpx auto;">
				<view style="width:700rpx;height: 80rpx;margin: 20rpx auto; line-height: 80rpx;">
					<text style="font-size: 35rpx; font-weight: bold;">评价</text>
					<text style="color: #333333;">(200)</text>
					<text style="margin: 0 20rpx 0 400rpx; color: #999999;">60%好评</text>
					<image style="width: 15rpx;height: 25rpx;" src="/static/mipmap-hdpi/gengduo.png" mode=""></image>
				</view>
				<view style="width: 750rpx;height: 170rpx;">
					<view v-for="(item, index) in sss2" style="padding: 5rpx 15rpx; background-color:#F7F8F9;display: inline-block; margin: 10rpx 25rpx; border-radius: 30rpx;">
						<text>{{ item.titles }}</text>
						<text>{{ item.titles1 }}</text>
					</view>
				</view>
				<view style="width: 100%;background-color: #FFFFFF;">
					<view class="swiper-container" style="margin-top: 20rpx;">
						<view class="swiper-container__box">
							<scroll-view scroll-x>
								<block v-for="(item, index) in 5">
									<view class="image-box" style="background-color: #F7F8F9; width: 100%; height:450rpx; border-radius: 20rpx;">
										<view style="width: 100%;height: 150rpx;" class="clearfix">
											<view style="width: 110rpx; height: 110rpx;float: left;margin-top: 25rpx;">
												<image style="width: 100rpx; height: 100rpx; border-radius: 50%;" src="/static/mipmap-hdpi/tc.png" mode=""></image>
											</view>
											<view style="width: 200rpx; height: 150rpx;float: left; margin: 0 10rpx;">
												<view style="font-weight: bold; font-size: 30rpx; width: 100%; height:75rpx;line-height: 75rpx;">习惯成魔</view>
												<view style="width: 100%; height:50rpx;line-height: 50rpx;color: #999999;">昨天:20:23</view>
											</view>
										</view>
										<view style="width: 100%;height: 60rpx;line-height: 60rpx;">很喜欢,说废寝忘食一点也不夸张!</view>
										<view style="width: 100%;height: 175rpx; ">
											<image style="width: 160rpx; height: 160rpx;margin: 7rpx 7rpx 7rpx 10rpx;" src="/static/mipmap-hdpi/chanpin3@2x.png" mode=""></image>
											<image style="width: 160rpx; height: 160rpx;margin: 7rpx 7rpx;" src="/static/mipmap-hdpi/chanpin6@3x.png" mode=""></image>
											<image style="width: 160rpx; height: 160rpx;margin: 7rpx 7rpx;" src="/static/mipmap-hdpi/chanpin5.png" mode=""></image>
											<image style="width: 160rpx; height: 160rpx;margin: 7rpx 7rpx;" src="/static/mipmap-hdpi/chanpin9.png" mode=""></image>
										</view>
										<view style="width: 100%;height: 60rpx;line-height: 60rpx;">
											<text style="margin: 0 180rpx 0 10rpx;color: #999999;">浏览32次</text>
											<image
												style="width: 30rpx; height: 30rpx;margin: 0 10rpx 0 200rpx;vertical-align: middle;"
												src="/static/mipmap-hdpi/pingjia.png"
												mode=""
											></image>
											<text style="color: #999999;vertical-align: middle;">0</text>
											<image
												style="width: 30rpx; height: 30rpx;margin: 0 10rpx 0 40rpx;vertical-align: middle;"
												src="/static/mipmap-hdpi/dianzhan.png"
												mode=""
											></image>
											<text style="color: #999999;vertical-align: middle;">赞</text>
										</view>
									</view>
								</block>
							</scroll-view>
						</view>
					</view>
				</view>
			</view>
		</view>
		<view style=" background-color: whites;">
			<view style=" background-color: white; width: 100%;height: 200rpx ;">
				<view class="ss6"><text style="margin:0 0 20rpx 55rpx;font-size: 36rpx;font-weight: 700;">活动专区</text></view>
			</view>
			<uni-grid :column="2" :showBorder="false" :square="false" :highlight="false" style="margin-top: -100rpx;">
				<uni-grid-item v-for="(item, index) in jdItems1" :key="index">
					<view class="cell" :style="{ marginLeft: index % 2 == 0 ? '10rpx' : '5rpx' }">
						<image :src="item.images" mode=""></image>
						<view style="background-color: white;margin-top: -20rpx;">
							<view>{{ item.title }}</view>
							<view>{{ item.title1 }}</view>
							<view>{{ item.details }}</view>
							<view style="display: inline-block;">¥{{ item.price }}</view>
							<navigator style="display: inline-block;" url="../shangpinxiangqing/shangpinxiangqing">
								<image style="width: 50rpx; height: 50rpx;margin-left: 150rpx;" :src="item.images1" mode=""></image>
							</navigator>
						</view>
					</view>
				</uni-grid-item>
			</uni-grid>
		</view>
		<view style="width: 100%; height: 180rpx;border-top: 1rpx solid #F2F2F2; background-color: white;">
			<view style="width: 700rpx; height: 180rpx;margin: 0 auto;display: flex;align-items: center;">
				<view style="float: left; width: 100rpx; height: 100rpx; margin: 0 10rpx;">
					<image style="width: 50rpx; height: 50rpx;" src="/static/mipmap-hdpi/kefu.png" mode=""></image>
					<view style="color: #666666 ;">客服</view>
				</view>
				<view style="float: left; width: 100rpx; height: 100rpx; margin: 0 40rpx ;">
					<image style="width: 50rpx; height: 50rpx; margin-left: 16rpx;" src="/static/mipmap-hdpi/gouwuche2.png" mode=""></image>
					<view style="color: #666666 ;">购物车</view>
				</view>
				<view class="ss5"><text style="width: 100%; height: 100rpx;display: flex;align-items: center;justify-content: center; color: white;">立即购买</text></view>
				<view class="ss4"><text style="width: 100%; height: 100rpx;display: flex;align-items: center;justify-content: center;color: white;">加入购物车</text></view>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			sss2: [
				{ titles: '拍摄效果好', titles1: '10' },
				{ titles: '操作简单', titles1: '10' },
				{ titles: '功能强大', titles1: '10' },
				{ titles: '满足家用', titles1: '10' },
				{ titles: '操作简单', titles1: '10' }
			],
			// sss3:[
			// 	{ image: '/static/mipmap-hdpi/tc.png' },
			// 	{ title: '习惯成魔'},
			// 	{xiangqing: '昨天:20:23'} ,
			// 	{liuyan: '很喜欢,说废寝忘食一点也不夸张!'},
			// 	{ image1: '/static/mipmap-hdpi/chanpin6@3x.png' },
			// 	{ image1: '/static/mipmap-hdpi/chanpin5.png' },
			// 	{ image1: '/static/mipmap-hdpi/chanpin4@2x.png' },
			// 	{ image1: '/static/mipmap-hdpi/chanpin3@2x.png' },
			// 	{ image1: '/static/mipmap-hdpi/chanpin7@2x.png' },
			// 	{ image1: '/static/mipmap-hdpi/chanpin8@3x.png' },
			// 	{ image1: '/static/mipmap-hdpi/chanpin9.png' },
			// 	{ image1: '/static/mipmap-hdpi/chanpintu@3x.png' }
			// ],
			// sss5:[
			// 	{ titels: '浏览32次'},
			// 	{images1: '/static/mipmap-hdpi/pingjia.png'},
			// 	{ling: '0'},
			// 	{images1: '/static/mipmap-hdpi/dianzhan.png'},
			// 	{ zan: '赞'}
			// ],
			jdItems1: [
				{
					images: '/static/tp/chanpin2@2x.png',
					title: '0-2岁触摸发声书：听，谁的音乐会？（巴赫/维瓦尔第/莫扎特/贝多芬）（套装全4册）婴幼儿宝宝触摸认知双语 会说话的早教启蒙有声',
					title1: '婴幼儿宝宝触摸认知双语 会说话的早教启蒙有声',
					price: '1324.00',
					price1: '132',
					images1: '/static/tp/jiagou@2x.png'
				},
				{
					images: '/static/tp/chanpin2@2x.png',
					title: '0-2岁触摸发声书：听，谁的音乐会？（巴赫/维瓦尔第/莫扎特/贝多芬）（套装全4册）婴幼儿宝宝触摸认知双语 会说话的早教启蒙有声',
					title1: '婴幼儿宝宝触摸认知双语 会说话的早教启蒙有声',
					price: '1324.00',
					price1: '132',
					images1: '/static/tp/jiagou@2x.png'
				},
				{
					images: '/static/tp/chanpin2@2x.png',
					title: '0-2岁触摸发声书：听，谁的音乐会？（巴赫/维瓦尔第/莫扎特/贝多芬）（套装全4册）婴幼儿宝宝触摸认知双语 会说话的早教启蒙有声',
					title1: '婴幼儿宝宝触摸认知双语 会说话的早教启蒙有声',
					price: '1324.00',
					price1: '132',
					images1: '/static/tp/jiagou@2x.png'
				},
				{
					images: '/static/tp/chanpin2@2x.png',
					title: '0-2岁触摸发声书：听，谁的音乐会？（巴赫/维瓦尔第/莫扎特/贝多芬）（套装全4册）婴幼儿宝宝触摸认知双语 会说话的早教启蒙有声',
					title1: '婴幼儿宝宝触摸认知双语 会说话的早教启蒙有声',
					price: '1324.00',
					price1: '132',
					images1: '/static/tp/jiagou@2x.png'
				},
				{
					images: '/static/tp/chanpin2@2x.png',
					title: '0-2岁触摸发声书：听，谁的音乐会？（巴赫/维瓦尔第/莫扎特/贝多芬）（套装全4册）婴幼儿宝宝触摸认知双语 会说话的早教启蒙有声',
					title1: '婴幼儿宝宝触摸认知双语 会说话的早教启蒙有声',
					price: '1324.00',
					price1: '132',
					images1: '/static/tp/jiagou@2x.png'
				},
				{
					images: '/static/tp/chanpin2@2x.png',
					title: '0-2岁触摸发声书：听，谁的音乐会？（巴赫/维瓦尔第/莫扎特/贝多芬）（套装全4册）婴幼儿宝宝触摸认知双语 会说话的早教启蒙有声',
					title1: '婴幼儿宝宝触摸认知双语 会说话的早教启蒙有声',
					price: '1325.00',
					price1: '132',
					images1: '/static/tp/jiagou@2x.png'
				}
			]
		};
	},
	methods: {}
};
</script>

<style lang="scss">
.ss8 {
	font-weight: 600;
	color: white;
	font-size: 30rpx;
	display: inline-block;
	margin: 0 30rpx 0 130rpx;
	border-bottom: 6rpx solid #ffffff;
}
.ss7 {
	background-image: url(/static/mipmap-hdpi/beijing.png);
	width: 100%;
	height: 110rpx;
	background-repeat: no-repeat;
	padding-top: 100rpx;
}
.ss6 {
	background-image: url(/static/tp/biaotizhuangshi@3x.png);
	background-repeat: no-repeat;
	background-size: 250rpx 20rpx;
	width: 300rpx;
	float: left;
	line-height: 20rpx;
	margin: 50rpx 0 50rpx 250rpx;
}
.ss5 {
	background-image: url(/static/mipmap-hdpi/goumai.png);
	background-repeat: no-repeat;
	background-size: 200rpx 90rpx;
	width: 200rpx;
	height: 100rpx;
	float: right;
}
.ss4 {
	background-image: url(/static/mipmap-hdpi/gouwu.png);
	background-repeat: no-repeat;
	background-size: 200rpx 90rpx;
	width: 200rpx;
	height: 100rpx;
	float: right;
}
.cell {
	width: 360rpx;
	border: 1px solid #f8f8f8;
	//box-shadow: 0 0 1px #F8F8F8;
	border-radius: 8rpx;
	margin-top: 10rpx;

	image {
		width: 100%;
		height: 260rpx;
	}

	> view {
		padding: 10rpx;

		> view {
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;

			&:first-of-type {
				font-size: 0.9em;
			}

			&:nth-of-type(2) {
				font-size: 0.7em;
				color: gray;
				margin: 8rpx 0;
			}

			&:nth-of-type(3) {
				color: red;
			}
		}
	}
}
.clearfix:after {
	/*伪元素是行内元素 正常浏览器清除浮动方法*/
	content: '';
	display: block;
	height: 0;
	clear: both;
	visibility: hidden;
}
.swiper-container {
	.swiper-container__box {
		box-sizing: border-box;
		// border:1px solid red;
		width: 100%;
		white-space: nowrap; // 横向滚动必要属性
		.image-box {
			display: inline-block; // 图片的外层定义成行内元素才可进行滚动
			width: 350px;
			height: 300px;
			// border:1px solid green;
			image {
				width: 100%;
				height: 100%;
			}
		}
	}
	// block 是必须定义的外层元素,否则无法进行横向滚动
}
</style>
