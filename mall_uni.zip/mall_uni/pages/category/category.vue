<template>
	<view style="background-color: white; width: 750rpx;border-top: 1rpx solid #E0E0E0; position: fixed;">
		<view style="width: 700rpx; display: flex; margin: 30rpx auto;">
			<scroll-view style="width: 20%; height: 100%;" scroll-y :style="{ height: winHeight + 'px' }">
				<view :class="{ cur: index == current }" class="menu-item" v-for="(item, index) in mallDicts" :key="index" @click="chooseItem(item,index)">{{ item.code }}</view>
			</scroll-view>

			<scroll-view style="width: 80%;" scroll-y :style="{ height: winHeight + 'px' }">
				<view style="width: 100%; height:100rpx;"><u-search :showAction="false" placeholder="请输入商品名称/类型"></u-search></view>
				<swiper :indicator-dots="false" :autoplay="true" :interval="3000" :duration="200" circular>
					<swiper-item v-for="(item, index) in lunboItem"><image style="width: 100%; height: 100%;" :src="item.images" mode=""></image></swiper-item>
				</swiper>
				<view style="width: 100%; height: 100rpx;display: flex; justify-content: space-between;align-items: center;">
					<text style="color: #E75E5A;font-weight: 600;">热门推荐</text>
					<view>
						<text style="font-size: 28rpx; color: #999999; vertical-align: middle;">查看更多</text>
						<image style="width: 15rpx; height: 25rpx;vertical-align: middle; margin: 0 10rpx;" src="/static/tp/zhuce/gengduo@2x.png" mode=""></image>
					</view>
				</view>
				<uni-grid :column="3" :showBorder="false" :square="false" :highlight="false">
					<uni-grid-item v-for="(item, index) in mallSort" :key="index">
						<view style="width: 150rpx; height: 250rpx; line-height: 50rpx;text-align:center;" :style="{ marginLeft: index % 2 == 0 ? '10rpx' : '5rpx' }">
							<image :src="item.imgSrc" style="width:150rpx;height:150rpx;"></image>
							<view style="font-size: 28rpx;">{{ item.name }}</view>
						</view>
					</uni-grid-item>
				</uni-grid>
			</scroll-view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			mallSort: [],
			lunboItem: [{ images: '/static/tp/banner@3x.png' }, { images: '/static/tp/banner@3x.png' }],
			mallDicts: [],
			current: 0
		};
	},
	onShow() {
		this.classification();
	},
	methods: {
		chooseItem(item,index) {
			console.log(item,index)
			this.current = index;
			
			//请求的代码 调用
			this.api.mallSort({categoryFirst: item.id }).then((res) => {
				if(res.flag){
					console.log(res)
					this.mallSort =  res.data;
				}
			}).catch((res) =>{ });
			
			
		},
		
		
		classification(){
			 //请求的代码 调用
			 this.api.classification({ }).then((res) => {
			 	if(res.flag){
			 		let mallDicts = res.data.mallDicts;
					let mallSort =  res.data.mallSort;
					this.mallDicts = mallDicts;
					this.mallSort = mallSort;
			 	}
			 }).catch((res) =>{ });
		},
		
	},
	computed: {
		winHeight() {
			return uni.getSystemInfoSync().windowHeight;
		}
		
	}
};
</script>

<style lang="scss">
.swiper-container {
	.swiper-container__box {
		box-sizing: border-box;
		// border:1px solid red;
		width: 100%;
		white-space: nowrap; // 横向滚动必要属性
		.image-box {
			display: inline-block; // 图片的外层定义成行内元素才可进行滚动
			width: 100px;
			height: 100px;
			// border:1px solid green;
			image {
				width: 100%;
				height: 100%;
			}
		}
	}
	// block 是必须定义的外层元素,否则无法进行横向滚动
}
.cell {
	width: 190rpx;
	// border: 1px solid gray;
	// box-shadow: 0 0 3px gray;
	border-radius: 8rpx;
	margin-top: 10rpx;

	image {
		width: 100%;
		height: 260rpx;
	}

	> view {
		padding: 10rpx 50rpx;

		> view {
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;

			&:first-of-type {
				font-size: 0.9em;
			}

			&:nth-of-type(2) {
				font-size: 0.7em;
				color: gray;
				margin: 8rpx 0;
			}

			&:nth-of-type(3) {
				color: red;
			}
		}
	}
}
.menu-item {
	padding: 10rpx 0 50rpx 0;
}

.menu-item.cur {
	// background-color: orange;
	color: #e75e5a;
	font-weight: bold;
}
</style>
