<template>
	<view
		style="background-image: url(/static/tp/wode/tuoyuan.png); width: 100%; height: 340rpx;background-repeat: no-repeat;background-size:100%;">
		<view style="width:700rpx; height: 340rpx; margin: 0 auto;padding-top:80rpx;">
			<view style=" height: 80rpx;" class="clearfix;">
				<uni-file-picker disable-preview :del-icon="false" return-type="object" :image-styles="imageStyles"
					style="display: inline-block;vertical-align: middle;">
					<u-avatar-group :urls="urls" size="55"></u-avatar-group>
				</uni-file-picker>
				<text style="margin: 0 15rpx; font-size: 28rpx;color: white;">逆光下的微笑</text>
				<view
					style="float: right;padding:13rpx 20rpx 20rpx; border-radius: 40rpx; border: 1rpx solid #FFFFFF; margin-top: 12rpx;">
					<image style="width: 30rpx; height: 30rpx;vertical-align: middle;" src="/static/tp/wode/hongbao.png"
						mode=""></image>
					<text style="padding:0 10rpx; font-size: 28rpx;vertical-align: middle; color: white;">拼单返现</text>
				</view>
			</view>
			<view style="width: 100%; height: 60rpx;margin-top: 30rpx; margin:20rpx; 0">
				<view style="float: left;width: 150rpx;padding:0 0 0 20rpx; border-right:1rpx  solid #fff;">
					<view style="color: white;margin: 0 20rpx; font-size: 20rpx;">0.00</view>
					<view style="color: white;font-size: 20rpx;">余额(元)</view>
				</view>
				<view
					style="float: left;width: 150rpx;padding:0 0 0 40rpx; border-right:1rpx  solid #fff;margin:0 65rpx ;">
					<view style="color: white;margin: 0 20rpx;font-size: 20rpx;">0</view>
					<view style="color: white;font-size: 20rpx;">积分</view>
				</view>
				<view style="float: left;width: 150rpx;padding:0 0 0 40rpx;">
					<view style="color: white;margin: 0 30rpx;font-size: 20rpx;">0</view>
					<view style="color: white;font-size: 20rpx;">优惠卷</view>
				</view>
			</view>
			<view
				style="background-color:#FEDAD0; border-top-right-radius: 20rpx; border-top-left-radius: 20rpx; height: 80rpx; display: flex;justify-content:space-between;align-items: center;">
				<text style="font-size: 30rpx;color: #E84444;margin: 0 10rpx;">拼单卡品牌权益</text>
				<image style="width: 15rpx; height: 20rpx;margin: 0 10rpx;	" src="/static/tp/wode/fengduo2.png" mode="">
				</image>
			</view>
		</view>
		<view style="width:750rpx; height: 250rpx; background-color: #FFFFFF; margin-top: -80rpx;">
			<view style=" width:700rpx; height: 250rpx; margin: 0 auto;">
				<view style="height: 80rpx;display: flex;justify-content: space-between;align-items: center;">
					<navigator url="./querendd/querendd" style="">
						<text style="font-size: 30rpx;font-weight: bold;vertical-align: middle;">我的订单</text>
					</navigator>
					<navigator url="dingdan/dingdan" style="">
						<text style="color: #B8B8B8;font-size: 30rpx;vertical-align: middle;">查看全部</text>
						<image style="width: 15rpx; height: 25rpx;vertical-align: middle;"
							src="/static/tp/wode/gengduo.png" mode=""></image>
					</navigator>
				</view>
				<view style="margin-top: 10rpx;">
					<uni-grid :column="5" :showBorder="false">
						<uni-grid-item v-for="(item, index) in iconFt" :key="index">
							<view style="width:130rpx ; height: 100rpx;text-align: center;">
								<image style="width: 45rpx; height: 45rpx;" :src="item.image" mode=""></image>
								<view style="width: 130rpx;height: 70rpx;line-height: 70rpx; font-size: 15rpx;">
									{{ item.title }}</view>
							</view>
						</uni-grid-item>
					</uni-grid>
				</view>
			</view>
		</view>
		<view style="width:750rpx; height: 150rpx; background-color: #FFFFFF; margin: 15rpx 0;">
			<view style=" width:700rpx; height: 100rpx; margin: 0 auto;padding-top:15rpx ;">
				<view style="height: 100rpx;width: 100%;">
					<uni-grid :column="5" :showBorder="false">
						<uni-grid-item v-for="(item, index) in iconFt1" :key="index">
							<view style="width:130rpx ; height: 100rpx;text-align: center;">
								<image style="width: 45rpx; height: 45rpx;" :src="item.image" mode=""></image>
								<view style="width: 130rpx;height: 0rpx;line-height: 70rpx; font-size: 15rpx;">
									{{ item.title }}</view>
							</view>
						</uni-grid-item>
					</uni-grid>
				</view>
			</view>
		</view>
		<view style="width:750rpx; height: 300rpx; background-color: #FFFFFF; margin: 15rpx 0;">
			<view style=" width:700rpx; height: 160rpx; margin: 0 auto;padding-top:20rpx ;">
				<view style="height: 400rpx;width: 100%;">
					<uni-grid :column="5" :showBorder="false">
						<uni-grid-item v-for="(item, index) in iconFt2" :key="index">
							<view style="width:120rpx ; height: 120rpx;text-align: center;">
								<image style="width: 40rpx; height: 40rpx;" :src="item.image" mode=""></image>
								<view style="width: 120rpx;height: 70rpx;font-size: 15rpx;line-height: 70rpx;">
									{{ item.title }}</view>
							</view>
						</uni-grid-item>
					</uni-grid>
				</view>
			</view>
		</view>
		<view style="height: 110rpx; display: flex;align-items: center;">
			<image style="width: 100%; height: 100rpx;" src="/static/tp/wode/jiaoniang.png" mode=""></image>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				urls: ['https://cdn.uviewui.com/uview/album/1.jpg'],
				iconFt2: [{
						image: '/static/tp/wode/kanjia.png',
						title: '砍价专区'
					},
					{
						image: '/static/tp/wode/yushou.png',
						title: '我的预售'
					},
					{
						image: '/static/tp/wode/jiangpin.png',
						title: '我的奖品'
					},
					{
						image: '/static/tp/wode/dazhuanpan.png',
						title: '大转盘任务'
					},
					{
						image: '/static/tp/wode/shouhuodizhi.png',
						title: '收货地址'
					},
					{
						image: '/static/tp/wode/pinjia.png',
						title: '我的评价'
					},
					{
						image: '/static/tp/wode/kefu.png',
						title: '官方客服'
					},
					{
						image: '/static/tp/wode/shezhi.png',
						title: '设置'
					}
				],
				iconFt1: [{
						image: '/static/tp/wode/tuyuan.png',
						title: '优惠卷'
					},
					{
						image: '/static/tp/wode/shouchang.png',
						title: '商品收藏'
					},
					{
						image: '/static/tp/wode/dianpu.png',
						title: '店铺收藏'
					},
					{
						image: '/static/tp/wode/jilu.png',
						title: '历史浏览'
					},
					{
						image: '/static/tp/wode/shouhou.png',
						title: '退款售后'
					}
				],
				iconFt: [{
						image: '/static/tp/wode/daifukuan.png',
						title: '待付款'
					},
					{
						image: '/static/tp/wode/fenxiang.png',
						title: '待分享'
					},
					{
						image: '/static/tp/wode/fahuo.png',
						title: '待发货'
					},
					{
						image: '/static/tp/wode/shouhuo.png',
						title: '待收货'
					},
					{
						image: '/static/tp/wode/pingjia.png',
						title: '待评价'
					}
				],
				imageStyles: {
					width: 50,
					height: 50,
					border: {
						radius: '50px'
					}
				}
			};
		},
	

	onShow() {
		//获取用户收到的信息
		this.goEasy.im.latestConversations({
			onSuccess: function(result) {
				if (result.content.unreadTotal > 0) {
					uni.setTabBarBadge({
						index: 3,
						text: result.content.unreadTotal.toString()
					});
				} else {
					uni.removeTabBarBadge({
						index: 3
					});
				}
			},
			onFailed: function(error) {
				//获取失败
				uni.hideLoading()
				console.log("失败获取最新会话列表, code:" + error.code + " content:" + error.content);
			}
		});
		
		
	},

	methods: {
		
	},
}
</script>

<style>
	.clearfix:after {
		/*START 真正起到清除浮动的代码*/
		content: '';
		display: block;
		clear: both;
		/*END 真正起到清除浮动的代码*/
		height: 0;
	}
</style>
