<template>
	<view>
		<view class="beijingtu1"><view class="beijingtu"></view></view>
		<view style="width: 750rpx; height: 800rpx; display: flex;justify-content: center;align-items: center;">
			<view style="width: 650rpx; height: 900rpx;">
				<view style="width: 100%; height: 100rpx;"><u--input prefixIcon="account-fill" placeholder="请输入用户名" v-model="name"></u--input></view>
				<view style="width: 100%; height: 100rpx; display: flex; justify-content:space-between;">
					<view>
						<navigator url="area/area">
						<view style="height: 75rpx; width: 120rpx; border: 1rpx solid #cccccc; border-radius: 10rpx; display: flex;justify-content: space-between;align-items: center;">
							<text style="color: #999999;">{{ areaCode }}</text>
							<image style="width: 25rpx; height: 20rpx; margin: 0 10rpx;" src="/static/tp/zhuce/qiehuan1.png" mode=""></image>
						</view>
						</navigator>
					</view>
					<view>
						<u--input
							placeholder-style="font-size:30rpx; margin:0 10rpx;"
							placeholder="手机号码"
							style=" min-height: 50rpx; height: 50rpx; width: 460rpx;"
							v-model="telephoneNumber"
						></u--input>
					</view>
				</view>
				<view style="width: 100%; height: 100rpx;"><u--input type="password" prefixIcon="lock" placeholder="请输入密码" v-model="pass"></u--input></view>
				<!-- <view style="width: 100%; height: 100rpx;"><u--input prefixIcon="checkbox-mark" placeholder="请输入验证码" v-model="name"></u--input></view> -->
				<view style="width: 100%; height: 100rpx;"><u--input prefixIcon="edit-pen" placeholder="请输入邀请码" v-model="lnviteCode"></u--input></view>
				<view style="width: 100%; height: 50rpx; color:#FF6F11; display:flex;justify-content: flex-end;" @click="login()">已有账户，去登录</view>
				<view style="width: 650rpx;height: 150rpx;display: flex;align-items: center;"><view class="chuceanniu" @click="userRegistration()">注册</view></view>
				<view style="width: 100%; height: 90rpx;">
					<view style="width: 650rpx; height: 90rpx;">
						<image style="width: 35rpx; height: 35rpx;vertical-align: middle; margin: 0 20rpx;" src="/static/denglu/verification code_agree.png" mode=""></image>
						<text style="color:#999992;vertical-align: middle;font-size: 15rpx;">已阅读同意</text>
						<text style="color:#F86451;vertical-align: middle;font-size: 15rpx;">《用户协议》</text>
						<text style="color:#999999;vertical-align: middle;font-size: 15rpx;">以及</text>
						<text style="color:#F86451;vertical-align: middle;font-size: 15rpx;">《隐私协议》</text>
						<text style="color:#F86451;vertical-align: middle;font-size: 15rpx;">以及</text>
						<text style="color:#F86451;vertical-align: middle;font-size: 15rpx;">《中国</text>
						<view style="width: 650rpx; height: 50rpx; display: flex;justify-content: center;font-size: 15rpx;color:#F86451;">联通认证服务条例》</view>
					</view>
				</view>
			</view>	
		</view>
		<u-popup :show="show" :round="10" mode="top" @close="close"@open="open" >
				<view>
		            <text>人生若只如初见，何事秋风悲画扇</text>
				</view>
			</u-popup>
	</view>
</template>

<script>
//注册页面
export default {
	data() {
		return {
			show:false,
			name: '',
			telephoneNumber: '',
			nation: '1',
			pass: '',
			areaCode: '+855',
			lnviteCode: ''
		};
	},
	methods: {
		 open() {
		        // console.log('open');
		      },
		      close() {
		        this.show = false
		        // console.log('close');
		      },
		userRegistration() {
			let reg = '^[a-zA-Z0-9]{4,20}$';
			if (this.name.match(reg) == null) {
				return uni.showToast({
					title: '用户名必须为4到20位数字或英文字母',
					duration: 5000,
					icon: 'none'
				});
			}
			if(this.nation == ''){
				return uni.showToast({
					title: '请选择所在国家',
					duration: 5000,
					icon: 'none'
				});
			}
			if (this.telephoneNumber == '') {
				return uni.showToast({
					title: '电话号码不能为空',
					duration: 5000,
					icon: 'none'
				});
			}
			if (this.pass == '' || this.pass.length < 4) {
				return uni.showToast({
					title: '密码不能小于4位数',
					duration: 5000,
					icon: 'none'
				});
			}
			if (this.lnviteCode == '') {
				return uni.showToast({
					title: '邀请码不能为空',
					duration: 5000,
					icon: 'none'
				});
			}
			let params = {
				name: this.name,
				pass: this.pass,
				lnviteCode: this.lnviteCode,
				telephoneNumber: this.telephoneNumber,
				nation: this.nation
			};
			this.api
				.userRegistration(params)
				.then(res => {
					if (res.flag) {
						uni.showToast({
							title: '恭喜你注册成功,3秒之后将会你自动跳转到登录界面',
							duration: 3000,
							icon: 'none'
						});
						setTimeout(() => {
							this.login();
						}, 2000);
						return;
					}

					if (res.code == -3) {
						return uni.showToast({
							title: '用户名已经被占用,请更换一个用户名',
							duration: 5000,
							icon: 'none'
						});
					}
					if (res.code == -4) {
						return uni.showToast({
							title: '你所选择的国家或地区不存在你可以联系客服进行处理',
							duration: 5000,
							icon: 'none'
						});
					}
					if (res.code == -5) {
						return uni.showToast({
							title: '该手机号码已经被注册,请换一个手机号码',
							duration: 5000,
							icon: 'none'
						});
					}
					if (res.code == -6) {
						return uni.showToast({
							title: '你输入的邀请码不正确,你可以联系邀请你的朋友进行核对或者联系客服进行帮助',
							duration: 5000,
							icon: 'none'
						});
					}
				})
				.catch(() => {});
		},
		login() {
			uni.navigateTo({
				url: '../login/login'
			});
		}
	}
};
</script>

<style>
.chuceanniu {
	background-size: 650rpx;
	color: white;
	display: flex;
	justify-content: center;
	align-items: center;
	width: 650rpx;
	height: 100rpx;
	background-image: url(/static/denglu/anniu121.png);
	background-repeat: no-repeat;
}
.beijingtu1 {
	display: flex;
	justify-content: center;
	align-items: flex-end;
	width: 750rpx;
	height: 450rpx;
}
.beijingtu {
	width: 400rpx;
	height: 400rpx;
	background-image: url(/static/tp/zhuce/beijing1.png);
	background-repeat: no-repeat;
	background-size: 400rpx;
}
</style>
