<template>
	<view>
		<view style="width: 100%;">
			<view style="width: 700rpx; height: 200rpx;margin: 0 auto;">
				 <view style="width: 700rpx; height:100rpx; border-bottom: 1rpx solid #CCCCCC;line-height: 100rpx;color: #cccccc;">A</view>
				<view v-for="(item,index) in areaList"   style="width:700rpx; height: 100rpx;display: flex;justify-content: space-between;align-items: center;">
					<view @click="intoRegister(item)">
						<text>{{ item.countryName }}</text>
						<text style="padding: 5rpx 10rpx; background-color: #E2E2E2; border-radius: 10rpx;">{{ item.areaCode }}</text>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			areaList:[]
		};
	},
	onShow() {
		this.countryRegion()
	},
	methods: {
		intoRegister(item){
			let pages = getCurrentPages();  //获取所有页面栈实例列表
			let prevPage = pages[ pages.length - 2];  //上一页页面实例
			prevPage.$vm.nation = item.id
			prevPage.$vm.areaCode = item.areaCode
			uni.navigateBack({
			    delta: 1
			});
		},
		countryRegion(){
			this.api.countryRegion({ }).then((res) => {
				console.log(res)
				if(res.flag){
					this.areaList = res.data;
				}
			}).catch((res) =>{ });
		}
	}
};
</script>

<style></style>
