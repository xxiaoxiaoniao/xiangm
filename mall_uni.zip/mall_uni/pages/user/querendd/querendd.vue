<template>
	<view>
		<view style="width: 100%; height: 250rpx; background-color: #F2F2F2;display: flex;align-items: center;justify-content: center;">
			<view style="width: 700rpx;height: 200rpx;background-color: #FFFFFF;display: flex; border-radius:10rpx;">
				<!-- <map style="width: 100%; height: 300px;" :latitude="latitude" :longitude="longitude" :markers="covers"></map> -->
				<view style="width: 140rpx; height: 200rpx;display: flex; align-items: center;justify-content: center;">
					<map class="mapstyle" :latitude="latitude" :include-points="includePoints" :longitude="longitude" :markers="markers"></map>
				</view>
				<view style="width: 550rpx; height: 200rpx;">
					<view style="display:flex; width: 100%; height: 55rpx;align-items: center;margin: 0 20rpx 0 500rpx;">
						<image style="width:30rpx; height: 30rpx;" src="/static/shangpxqy/xiugai.png" mode=""></image>
					</view>
					<view style="width:100%; height:100rpx;line-height: 50rpx;">
						<view>
							<text style="font-weight: bold;margin: 0 20rpx 0 5rpx;font-size: 30rpx;">白杨</text>
							<text style="color: #999999; ">13365632698</text>
						</view>
						<view style="color: #666666;margin: 0 5rpx;">广东省广州市通信产业园1楼106号</view>
					</view>
				</view>
			</view>
		</view>
		<view class="wwsy">
			<view style="width: 700rpx; height:660rpx;">
				<view style="width: 100%; height: 200rpx;display: flex;">
					<view><image style="width: 200rpx; height:200rpx;border-radius:10rpx;" src="/static/shangpxqy/chanpintu@3x.png" mode=""></image></view>
					<view style="width: 500rpx; height: 200rpx;">
						<view style="width: 500rpx;height: 130rpx;font-weight: bold;">DJI大疆无人机新款六期免息Mavic2Pro/zoom专业版无人机可折叠航拍选配带屏遥</view>
						<view style="width: 500rpx; height: 70rpx; line-height: 70rpx;">
							<text style="color:#FF6600;font-size: 35rpx;font-weight: bold;">￥13186</text>
							<text style="margin: 0 20rpx 0 310rpx;">x1</text>
						</view>
					</view>
				</view>
				<view style="width: 100%; height: 90rpx; border-bottom: 1rpx solid #F2F2F2; display: flex;justify-content:space-between;align-items: center;">
					<text style="color:#666666;font-weight: bold;font-size: 30rpx;">商品金额:</text>
					<text style="color:#FF6600;">￥13186</text>
				</view>
				<view style="width: 100%; height: 90rpx; border-bottom: 1rpx solid #F2F2F2; display: flex;justify-content:space-between;align-items: center;">
					<text style="color:#666666;font-weight: bold;font-size: 30rpx;">活动满减:</text>
					<text style="color:#FF6600;">-￥50</text>
				</view>
				<view style="width: 100%; height: 90rpx; border-bottom: 1rpx solid #F2F2F2; display: flex;justify-content:space-between;align-items: center;">
					<text style="color:#666666;font-weight: bold;font-size: 30rpx;">优惠卷:</text>
					<view>
						<text style="color:#FF6600;vertical-align: middle;">-￥20</text>
						<image style="width:15rpx; height: 25rpx;vertical-align: middle; margin: 0 0 0 10rpx;" src="/static/shangpxqy/qiehuan.png" mode=""></image>
					</view>
				</view>
				<view style="width: 100%; height: 90rpx; border-bottom: 1rpx solid #F2F2F2; display: flex;justify-content:space-between;align-items: center;">
					<text style="color:#666666;font-weight: bold;font-size: 30rpx;">运费:</text>
					<text style="color:#999999">包邮</text>
				</view>
				<view style="width: 100%; height: 90rpx;display: flex;justify-content:space-between;align-items: center;">
					<text style="color:#666666;font-weight: bold;font-size: 30rpx;">实付金额:</text>
					<text style="color:#FF6600;">￥13186</text>
				</view>
			</view>
		</view>
		<view style="width: 100%; height: 540rpx;background-color: white; display: flex;justify-content: center;align-items: center;">
			<view style="width: 700rpx;height: 500rpx;">
				<text style="color: #666666;">留言</text>
				<view style="width: 100%; height: 300rpx; background-color:#F2F2F2;border-radius: 10rpx;"></view>
				<view style="width: 100%;height: 190rpx;display: flex;">
					<view style="width:350rpx; height: 190rpx;display: flex;justify-content:flex-start; align-items: center;">
						<text style="color: #666666;">订单支付</text>
						<text style="font-size: 35rpx; font-weight: bold;color:#FF6600; margin:0 20rpx;">￥13116</text>
					</view>

					<view style="width:350rpx; height: 190rpx;display: flex;justify-content:flex-end; align-items: center;">
						<view
							@click="showModal"
							style=" color: white; width:200rpx;height:65rpx;background-image: url(/static/shangpxqy/anniu.png);background-repeat:no-repeat; background-size: 200rpx;display: flex;justify-content: center; align-items: center;"
						>
							提交订单
						</view>
					</view>
				</view>
			</view>
		</view>
		<u-modal :show="show" :showConfirmButton="false" :zoom="true">
			<view
				style="width: 700rpx; height: 600rpx; background-image: url(/static/denglu/beijin@3x.png);background-size: 570rpx;background-repeat: no-repeat;display: flex;align-items: flex-end;"
			>
				<view style="width: 550rpx; height: 600rpx;display: flex;justify-content:flex-end;">
					<view style="width: 450rpx; height: 600rpx;background-color: #007AFF;">
						<view style="width: 550rpx;height: 200rpx;">
							<view>支付订单</view>
							<view>加入会员满5000减50</view>
						</view>
						<view style="width: 550rpx;height: 100rpx;">
							<text>银行卡快捷支付</text>
							<image style="width: 40rpx;height: 40rpx;" src="/static/denglu/shezhi@2x.png" mode=""></image>
						</view>
						<view style="width: 550rpx;height: 100rpx;">
							<text>银行卡快捷支付</text>
							<image style="width: 40rpx;height: 40rpx;" src="/static/denglu/weigouxuan@2x.png" mode=""></image>
						</view>
						<view style="width: 550rpx;height: 100rpx;">
							<text>银行卡快捷支付</text>
							<image style="width: 40rpx;height: 40rpx;" src="/static/denglu/weigouxuan@2x.png" mode=""></image>
						</view>
						<view>
							去付款
						</view>
					</view>
					<view @click="confirm" style="width: 550rpx; height: 100rpx;position: fixed; bottom: 200rpx;text-align: center;">
						<image style="width: 50rpx;height: 50rpx;" src="/static/denglu/quxiao@2x2.png" mode=""></image>
					</view>
				</view>
			</view>
		</u-modal>
	</view>
</template>

<script>
export default {
	data() {
		return {
			show: false,
			markers: [],
			longitude: '',
			latitude: '',
			includePoints: [],
			polyline: {}
		};
	},
	onLoad() {
		uni.getLocation({
			type: 'gcj02',
			success: res => {
				console.log(res, '啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊');
				const { longitude, latitude } = res;
				this.longitude = longitude;
				this.latitude = latitude;
				const includePoints = [
					{
						longitude: 120.96617296006944,
						latitude: 31.372928059895834
					},
					{
						longitude: 120.98181,
						latitude: 31.38475
					}
				];
				const polyline = [
					{
						points: [
							{
								latitude: 31.38475,
								longitude: 120.98181
							},
							{
								latitude: 31.372928059895834,
								longitude: 120.96617296006944
							}
						],
						width: 2,
						color: '#0000AA'
					}
				];
				const list = [
					{
						id: 12001,
						longitude: this.longitude,
						latitude: this.latitude,
						iconPath: '/static/shangpxqy/dingwei.png',
						width: 20,
						height: 20,
						alpha: 0.5,
						label: {
							content: 'me',
							color: '#333',
							fontSize: 14,
							borderRadius: 20,
							textAlign: 'center'
						},
						callout: {
							content: '我的位置',
							color: '#333',
							fontSize: 14,
							borderRadius: 20,
							textAlign: 'center'
						}
					},
					{
						id: 12002,
						longitude: 120.96617296006944,
						latitude: 31.372928059895834,
						iconPath: '/static/shangpxqy/dingwei.png',
						width: 20,
						height: 20,
						alpha: 0.5,
						label: {
							content: 'you',
							color: '#333',
							fontSize: 14,
							borderRadius: 20,
							textAlign: 'center'
						},
						callout: {
							content: '终点',
							color: '#333',
							fontSize: 14,
							borderRadius: 20,
							textAlign: 'center'
						}
					}
				];
				// this.$nextTick(() => {
				// 	this.$set(this, 'markers', list)
				// 	this.$set(this, 'includePoints', includePoints)
				// 	this.$set(this, 'polyline', polyline)
				// })
			}
		});
	},
	methods: {
		showModal() {
			this.show = true;
		},
		confirm() {
			// 3秒后自动关闭
			this.show = false;
		}
	}
};
</script>

<style>
.mapstyle {
	width: 90rpx;
	height: 90rpx;
	background-image: url(/static/shangpxqy/dingwei.png);
	background-repeat: no-repeat;
	background-size: 90rpx;
	border-radius: 50%;
}
.wwsy {
	width: 100%;
	height: 700rpx;
	background-color: white;
	border-top-left-radius: 30rpx;
	border-top-right-radius: 30rpx;
	margin: 6rpx 0 30rpx 0;
	display: flex;
	justify-content: center;
	align-items: center;
}
</style>
