<template>
	<view>
		<uni-segmented-control
			:current="current"
			:values="items"
			@clickItem="onClickItem"
			styleType="text"
			activeColor="#E84444"
			style="border-top: 1rpx solid #F4F4F4; background-color:white; height: 150rpx; border-bottom: 1rpx solid #D2D3D4;"
		></uni-segmented-control>
		<view class="content">
			<view v-show="current === 0">
				<view v-for="(item, index) in 6">
					<view class="wwss6"><view class="wwss5">订单编号:19484455772</view></view>
					<view style="width:700rpx;height: 330rpx;margin: 20rpx auto;">
						<view class="wwss4">
							<view class="wwss3"><image style="width: 200rpx; height: 200rpx;" src="/static/tp/wode/chanpintu@3x.png" mode=""></image></view>
							<view style="width: 470rpx; height: 300rpx;float: right;">
								<view style="font-weight: 600;">DJI大疆无人机新款六期免息Mavic2Pro/zoom专业版无人机可折叠航拍选</view>
								<view style="font-size: 20rpx; color: #666666;">Macvic2专业版+配件包+随心换</view>
								<view style="font-size: 35rpx;font-weight: bold;color: #FF5907;">￥13186</view>
								<view class="wwss2">
									<view class="wwss">取消订单</view>
									<view class="wwss1">去付款</view>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
			<view v-show="current === 1">
				<view v-for="(item, index) in 6">
					<view class="wwss6"><view class="wwss5">订单编号:19484455772</view></view>
					<view style="width:700rpx;height: 330rpx;margin: 20rpx auto;">
						<view class="wwss4">
							<view class="wwss3"><image style="width: 200rpx; height: 200rpx;" src="/static/tp/wode/chanpintu@3x.png" mode=""></image></view>
							<view style="width: 470rpx; height: 300rpx;float: right;">
								<view style="font-weight: 600;">DJI大疆无人机新款六期免息Mavic2Pro/zoom专业版无人机可折叠航拍选</view>
								<view style="font-size: 20rpx; color: #666666;">Macvic2专业版+配件包+随心换</view>
								<view style="font-size: 35rpx;font-weight: bold;color: #FF5907;">￥13186</view>
								<view class="wwss2">
									<view class="wwss">取消订单</view>
									<view class="wwss1">去付款</view>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
			<view v-show="current === 2">
				<view v-for="(item, index) in 6">
					<view class="wwss6"><view class="wwss5">订单编号:19484455772</view></view>
					<view style="width:700rpx;height: 330rpx;margin: 20rpx auto;">
						<view class="wwss4">
							<view class="wwss3"><image style="width: 200rpx; height: 200rpx;" src="/static/tp/wode/chanpintu@3x.png" mode=""></image></view>
							<view style="width: 470rpx; height: 300rpx;float: right;">
								<view style="font-weight: 600;">DJI大疆无人机新款六期免息Mavic2Pro/zoom专业版无人机可折叠航拍选</view>
								<view style="font-size: 20rpx; color: #666666;">Macvic2专业版+配件包+随心换</view>
								<view style="font-size: 35rpx;font-weight: bold;color: #FF5907;">￥13186</view>
								<view class="wwss2">
									<view class="wwss">取消订单</view>
									<view class="wwss1">去付款</view>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
			<view v-show="current === 3">
				
					<view style="width: 750rpx;height: 400rpx;" v-for="(item, index) in 9">
						<view style="width: 700rpx; height: 400rpx; margin: 0 auto;">
							<view style="width: 700rpx; height: 80rpx;line-height: 80rpx; color: #666666;font-weight: 600;font-size: 28rpx; margin: 0 20rpx;">
								订单编号:19484455772
							</view>
							<view style="width: 660rpx;height: 250rpx;background-color:white; margin: 0 auto;border-top-right-radius: 20rpx;border-top-left-radius: 20rpx;">
								<navigator url="goods/goods">
									<view style="width: 660rpx;height: 250rpx; margin: 0 auto;display: flex; align-items: center; ">
										<view style="width: 220rpx; height: 230rpx;display: flex;justify-content: center;align-items: center;">
											<image style="width: 200rpx; height: 200rpx;" src="/static/tp/wode/chanpintu@3x.png" mode=""></image>
										</view>
										<view style="width: 440rpx; height: 220rpx;display: flex;align-items: center;">
											<view style="height: 170rpx;">
												<view style="font-weight: 500;font-size: 26rpx; height: 70rpx;" class="gridItem1">
													DJI大疆无人机新款六期免息Mavic2Pro/zoom专业版无人机可折叠航拍选
												</view>
												<view style="font-size: 20rpx; color: #666666; height: 50rpx;line-height: 50rpx;">Macvic2专业版+配件包+随心换</view>
												<view style="font-size: 35rpx;font-weight: bold;color: #FF5907;height: 50rpx;line-height: 50rpx;">￥13186</view>
											</view>
										</view>
									</view>
								</navigator>
								<view
									style="width: 660rpx;height: 70rpx; background-color: white; display: flex; justify-content: space-around;align-items: center;border-bottom-right-radius: 20rpx;border-bottom-left-radius: 20rpx;"
								>
									<view style=" height: 70rpx;color: #999999; line-height: 70rpx; font-size: 20rpx;">更多</view>
									<view class="s2">延长收货</view>
									<view class="s2">取消订单</view>
									<view class="s1">确认收货</view>
								</view>
							</view>
						</view>
					</view>
				
			</view>
			<view v-show="current === 4">
				<view v-for="(item, index) in 6">
					<view class="wwss6"><view class="wwss5">订单编号:19484455772</view></view>
					<view style="width:700rpx;height: 330rpx;margin: 20rpx auto;">
						<view class="wwss4">
							<view class="wwss3"><image style="width: 200rpx; height: 200rpx;" src="/static/tp/wode/chanpintu@3x.png" mode=""></image></view>
							<view style="width: 470rpx; height: 300rpx;float: right;">
								<view style="font-weight: 600;">DJI大疆无人机新款六期免息Mavic2Pro/zoom专业版无人机可折叠航拍选</view>
								<view style="font-size: 20rpx; color: #666666; height: 60rpx;line-height: 60rpx;">Macvic2专业版+配件包+随心换</view>
								<view style="font-size: 35rpx;font-weight: bold;color: #FF5907;">￥13186</view>
								<view class="wwss2">
									<navigator url="../../logistics/logistics">
									<view class="wwss">查看物流</view>
									</navigator>
									<navigator url="evaluate/evaluate">
									<view class="wwss1">评价</view>
									</navigator>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			items: ['全部', '待付款', '待发货', '待收货', '待评价'],
			current: 0
		};
	},
	methods: {
		onClickItem(e) {
			if (this.current != e.currentIndex) {
				this.current = e.currentIndex;
			}
		}
	}
};
</script>

<style>
.s2 {
	width: 155rpx;
	height: 45rpx;
	background-color: #ffffff;
	border-radius: 30rpx;
	display: flex;
	justify-content: center;
	align-items: center;
	border: 1rpx solid #999999;
	color: #666666;
	font-size: 20rpx;
}
.s1 {
	background-image: url(/static/tp/wode/anniu.png);
	background-repeat: no-repeat;
	width: 160rpx;
	height: 45rpx;
	background-size: 150rpx;
	display: flex;
	justify-content: center;
	line-height: 45rpx;
	color: white;
	font-size: 20rpx;
}
.wwss {
	float: left;
	width: 165rpx;
	height: 55rpx;
	background-color: #ffffff;
	border-radius: 30rpx;
	margin-left: 90rpx;
	display: flex;
	justify-content: center;
	align-items: center;
	border: 1rpx solid #999999;
	color: #666666;
}
.wwss1 {
	float: left;
	background-image: url(/static/tp/wode/anniu.png);
	background-repeat: no-repeat;
	width: 165rpx;
	height: 55rpx;
	background-size: 160rpx;
	margin-right: 20rpx;
	display: flex;
	justify-content: center;
	align-items: center;
	color: white;
}
.wwss2 {
	width: 100%;
	height: 100rpx;
	display: flex;
	justify-content: space-between;
	align-items: center;
	line-height: 100rpx;
}
.wwss3 {
	width: 230rpx;
	height: 204rpx;
	float: left;
	display: flex;
	justify-content: center;
	align-items: center;
}
.wwss4 {
	width: 700rpx;
	height: 330rpx;
	background-color: white;
	padding-top: 20rpx;
	border-radius: 10rpx;
}
.wwss5 {
	width: 700rpx;
	height: 100rpx;
	line-height: 100rpx;
}
.wwss6 {
	width: 700rpx;
	height: 100rpx;
	margin: 30rpx auto;
}
.gridItem1 {
	overflow: hidden;
	text-overflow: ellipsis;
	display: -webkit-box;
	-webkit-line-clamp: 2; //多行在这里修改数字即可
	-webkit-box-orient: vertical;
}
</style>
