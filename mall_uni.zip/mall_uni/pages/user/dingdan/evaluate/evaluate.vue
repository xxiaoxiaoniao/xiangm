<template>
	<view>
		<view style="width: 700rpx;margin: 0 auto;">
			<view style="width: 700rpx; height: 700rpx; background-color: white;border-radius: 15rpx;margin: 20rpx auto;">
				<view style="width: 660rpx;margin: 20rpx auto;padding-top: 20rpx;">
					<view style="width:100%;height: 230rpx; border-bottom: 1rpx solid #EEEEEE; display: flex; justify-content: space-between;">
						<view style="width: 200rpx;height: 230rpx; display: flex;align-items: center;">
							<image style="width: 200rpx; height: 200rpx;" src="/static/tp/wode/chanpintu@3x.png" mode=""></image>
						</view>
						<view style="width: 440rpx;height: 230rpx;">
							<view style="font-weight: 600; margin-top: 10rpx;" class="gridItem1">DJI大疆无人机新款六期免息Mavic2Pro/zoom专业版无人机可折叠航拍选</view>
							<view style="font-size: 20rpx; color: #666666; height: 60rpx;line-height: 60rpx;">Macvic2专业版+配件包+随心换</view>
							<view style="font-size: 35rpx;font-weight: bold;color: #FF5907;">￥13186</view>
						</view>
					</view>
					<view style="width:100%;height: 80rpx; display: flex; justify-content: space-around;align-items: center;">
						<view>
							<image style="width: 45rpx; height: 50rpx;vertical-align: middle;" src="/static/denglu/haoping@2x1.png" mode=""></image>
							<text style="vertical-align: middle; margin: 0 20rpx;color:#FF5907;">好评</text>
						</view>
						<view>
							<image style="width: 45rpx; height: 50rpx;vertical-align: middle;" src="/static/denglu/chaping@2x.png" mode=""></image>
							<text style="vertical-align: middle;margin: 0 20rpx;color:#999999;">中评</text>
						</view>
						<view>
							<image style="width: 45rpx; height: 50rpx;vertical-align: middle;" src="/static/denglu/chaping@2x.png" mode=""></image>
							<text style="vertical-align: middle;margin: 0 20rpx;color:#999999;">差评</text>
						</view>
					</view>
					<view style="width:100%;height: 340rpx; background-color: #F7F8F9; border-radius: 20rpx;">
						<u--textarea v-model="value2" placeholder="说点什么吧......" border="none" height="100" style="background-color:#F7F8F9;"></u--textarea>
						<image style="width: 100rpx; height: 100rpx;margin:0 20rpx;" src="/static/denglu/tianjiazhaopian@2x.png" mode=""></image>
						<image style="width: 100rpx; height: 100rpx;margin:0 20rpx;" src="/static/denglu/paisheshipin@3x.png" mode=""></image>
					</view>
				</view>
			</view>
			<view style="width: 700rpx;height: 80rpx;">
				<view style="border-left: 4rpx solid #FF4343;margin-left: 50rpx; padding:0 20rpx;">店铺评分</view>
			</view>
			<view style="width: 700rpx;height: 60rpx;display:flex;align-items: center; justify-content:space-around">
				描述相符
				<u-rate :count="count" v-model="value" :touchable="false" activeColor="#F75B1E"></u-rate>
			</view>
			<view style="width: 700rpx;height: 60rpx;display:flex;align-items: center; justify-content:space-around  ">
				物流服务
				<u-rate :count="count" v-model="value" :touchable="false" activeColor="#F75B1E"></u-rate>
			</view>
			<view style="width: 700rpx;height: 60rpx;display:flex;align-items: center; justify-content:space-around  ">
				服务态度
				<u-rate :count="count" v-model="value" :touchable="false" activeColor="#F75B1E"></u-rate>
			</view>
			<view style="width: 700rpx;height: 60rpx; display: flex;justify-content: flex-end;align-items: flex-end;">
				<view>
					<image style="width: 45rpx; height: 45rpx;vertical-align: middle;" src="/static/denglu/niming@2x.png" mode=""></image>
					<text style="vertical-align: middle;margin: 0 20rpx;">匿名评价</text>
				</view>
			</view>
			<view style="width: 100%;height: 100rpx; display: flex;justify-content:center;align-items: flex-end;">
				<view style="width: 550rpx;height: 80rpx; background-image: url(/static/denglu/anniu121.png); background-repeat: no-repeat;background-size: 550rpx;color: white;display: flex;justify-content: center;align-items: center;">
					提交评价
				</view>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {};
	},
	methods: {}
};
</script>

<style>
.gridItem1 {
	overflow: hidden;
	text-overflow: ellipsis;
	display: -webkit-box;
	-webkit-line-clamp: 2; //多行在这里修改数字即可
	-webkit-box-orient: vertical;
}
</style>
