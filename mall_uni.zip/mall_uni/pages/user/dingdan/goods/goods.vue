<template>
	<view>
		<view style="width: 100%;height: 300rpx;background-image: url(/static/denglu/tuoyuan.png);">
			<view style="width: 680rpx;height: 100rpx;margin: 0 auto;display: flex;align-items: flex-end;">
				<navigator url="../dingdan"><image style="width: 20rpx; height: 30rpx;" src="/static/denglu/fanhui.png" mode=""></image></navigator>
			</view>
			<view style="width: 700rpx;height: 130rpx;margin: 0 auto;">
				<view style="text-align: center;">
					<image style="width: 60rpx; height: 60rpx;" src="/static/denglu/shijian.png"></image>
					<view style="color: white;">待收货</view>
				</view>
			</view>
		</view>
		<view style="width:700rpx; margin: 0 auto;">
			<view style="width: 700rpx; height: 130rpx;display: flex; justify-content: space-between;align-items: center;">
				<view>
					<view style="display: flex;">
						<text style="font-weight: bold;">白杨</text>
						<text style="font-size: 28rpx;color: #999999;margin: 0 20rpx;">13345826957</text>
						<view
							style="width:80rpx;height: 40rpx;background-image: url(/static/denglu/anniu.png);background-repeat: no-repeat;background-size: 80rpx;font-size: 20rpx;color:white;text-align: center;"
						>
							默认
						</view>
					</view>
					<view style="font-size: 28rpx;color: #999999;height: 60rpx; line-height: 60rpx;">广东省广州市通信产业园1楼106号</view>
				</view>
				<view><image style="width: 15rpx; height: 25rpx;" src="/static/denglu/gengduo@2x.png"></image></view>
			</view>
			<view style="background-color: white; border-radius: 15rpx;">
				<view style="width: 700rpx; height: 250rpx;display: flex;align-items: center; justify-content: space-around;">
					<view style="width: 180rpx; height: 220rpx;display: flex;align-items: center;">
						<image style="width: 190rpx;height: 200rpx;" src="/static/denglu/chanpintu@3x.png" mode=""></image>
					</view>
					<view style="width: 490rpx; height:220rpx;">
						<view style="font-weight: 500;font-size: 26rpx; height: 70rpx;" class="gridItem1">DJI大疆无人机新款六期免息Mavic2Pro/zoom专业版无人机可折叠航拍选</view>
						<view style="font-size: 30rpx; color: #666666;height: 80rpx;line-height: 80rpx;">Macvic2专业版+配件包+随心换</view>
						<view style="height: 80rpx;line-height: 50rpx;display: flex;justify-content: space-between;">
							<text style="font-size: 35rpx;font-weight: bold;color: #FF5907;">￥13186</text>
							<text style="color: #999999;">x1</text>
						</view>
					</view>
				</view>
				<view style="width: 700rpx; height: 250rpx;display: flex;align-items: center; justify-content: space-around; background-color: white;">
					<view style="width: 180rpx; height: 220rpx;display: flex;align-items: center;">
						<image style="width: 190rpx;height: 200rpx;" src="/static/denglu/chanpintu@3x.png" mode=""></image>
					</view>
					<view style="width: 490rpx; height:220rpx;">
						<view style="font-weight: 500;font-size: 26rpx; height: 70rpx;" class="gridItem1">DJI大疆无人机新款六期免息Mavic2Pro/zoom专业版无人机可折叠航拍选</view>
						<view style="font-size: 30rpx; color: #666666;height: 80rpx;line-height: 80rpx;">Macvic2专业版+配件包+随心换</view>
						<view style="height: 80rpx;line-height: 50rpx;display: flex;justify-content: space-between;">
							<text style="font-size: 35rpx;font-weight: bold;color: #FF5907;">￥13186</text>
							<text style="color: #999999;">x2</text>
						</view>
					</view>
				</view>
			</view>
			<view v-for="(item, index) in www" style="display: flex; justify-content: space-between;">
				<view style="margin:20rpx 0; color: #666666;">{{ item.title }}</view>
				<view style="margin:20rpx 0; color: #999999;">{{ item.titles }}</view>
			</view>
			<view>
				<text style="color: #666666;font-weight: 600;">备注</text>
				<text style="color: #999999;margin: 0 30rpx;">买家备注信息</text>
			</view>
			<view style="width: 700rpx; height: 150rpx; display: flex;justify-content: flex-end;align-items: center;">
				<view
					style="margin: 0 20rpx;  width: 200rpx;height: 55rpx; border: 1rpx solid #999999;font-size: 30rpx; border-radius: 50rpx;color: #666666; display: flex;justify-content: center;align-items: center;"
				>
					再去逛逛
				</view>
				<view
					style=" margin: 0 20rpx; font-size: 30rpx;  width: 200rpx;height: 55rpx;background-image: url(/static/denglu/anniu2.png);background-repeat: no-repeat;background-size: 200rpx;display: flex;justify-content: center;align-items: center;color: white;"
				>
					确认收货
				</view>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			www: [
				{ title: '物流公司', titles: '中通快递' },
				{ title: '订单编号', titles: '12568545687' },
				{ title: '下单时间', titles: '2022-03-13 19:30:06' },
				{ title: '商品总价', titles: '￥39504' },
				{ title: '运费', titles: '包邮' },
				{ title: '优惠卷减免', titles: '-￥50' },
				{ title: '实际总支付', titles: '-￥39454' }
			]
		};
	},
	methods: {}
};
</script>

<style>
.gridItem1 {
	overflow: hidden;
	text-overflow: ellipsis;
	display: -webkit-box;
	-webkit-line-clamp: 2; //多行在这里修改数字即可
	-webkit-box-orient: vertical;
}
</style>
