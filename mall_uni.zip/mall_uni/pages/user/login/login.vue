<template>
	<view>
		<view class="beijingtu1"><view class="beijingtu"></view></view>
		<view style="width: 750rpx; height: 650rpx; display: flex;justify-content: center;align-items: center;">
			<view style="width: 650rpx; height: 650rpx;">
				<view style="width: 100%; height: 80rpx; color:#FF6F11; display:flex;justify-content: flex-end; " @click="registr()">注册账号</view>
				<view style="width: 100%; height: 100rpx;"><u--input prefixIcon="account" placeholder="请输入账号" v-model="userName"></u--input></view>
				<view style="width: 100%; height: 100rpx;"><u--input type="password" prefixIcon="lock" placeholder="请输入密码" v-model="password"></u--input></view>
				<view style="width: 650rpx; height: 60rpx; display: flex;justify-content: space-between;">
					<view>
						<image style="width: 35rpx; height: 35rpx;vertical-align: middle; margin: 0 10rpx 0 0;" src="/static/denglu/verification1.png" mode=""></image>
						<text style="color: #999999;font-size: 30rpx;">记住密码?</text>
					</view>
					<view style="color: #999999;font-size: 30rpx;">忘记密码</view>
				</view>
				<view style="width: 650rpx;height: 150rpx;display: flex;align-items: center;" @click="login()"><view class="chuceanniu">登录</view></view>
				<view style="width: 100%; height: 230rpx;display: flex;align-items: flex-end;">
					<view style="width: 650rpx; height: 90rpx;">
						<image style="width: 35rpx; height: 35rpx;vertical-align: middle; margin: 0 20rpx;" src="/static/denglu/verification1.png" mode=""></image>
						<text style="color:#999992;vertical-align: middle;font-size: 15rpx;">已阅读同意</text>
						<text style="color:#F86451;vertical-align: middle;font-size: 15rpx;">《用户协议》</text>
						<text style="color:#999999;vertical-align: middle;font-size: 15rpx;">以及</text>
						<text style="color:#F86451;vertical-align: middle;font-size: 15rpx;">《隐私协议》</text>
						<text style="color:#F86451;vertical-align: middle;font-size: 15rpx;">以及</text>
						<text style="color:#F86451;vertical-align: middle;font-size: 15rpx;">《中国</text>
						<view style="width: 650rpx; height: 50rpx; display: flex;justify-content: center;font-size: 15rpx;color:#F86451;">联通认证服务条例》</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
//登录页面
import IMService from "../../../lib/imservice";

import restApi from "../../../lib/restapi";

export default {
	data() {
		return {
			userName:'name',
			password:'1234'
		};
	},
	methods: {
		login(){
			let reg='^[a-zA-Z0-9]{4,20}$'
			if(this.userName.match(reg) == null){
				return uni.showToast({
					title: '用户名必须为4到20位数字或英文字母',
					duration: 5000,
					icon:'none'
				});
			}
			
			if(this.password == '' || this.password.length < 4){
				return uni.showToast({
					title: '登录密码不能小于4位数',
					duration: 5000,
					icon:'none'
				});
			}
			this.api.login({ 
				userName : this.userName,
				password : this.password
			}).then((res) => {
				if(res.flag){
					 uni.showToast({
						title: '恭喜您登录成功',
						duration: 5000,
						icon:'none'
					}); 
					uni.setStorageSync('token',res.desc);
					
					//保存用户的登录信息
					let currentUser = {
						uuid : res.data.id,
						avatar : res.data.avatar,
						name : res.data.nickName
					}
					uni.setStorageSync('currentUser',currentUser);
					//获取用户的朋友和群组
					 if(this.goEasy.getConnectionStatus() === 'disconnected') {
						getApp().globalData.imService = new IMService(this.goEasy,this.GoEasy);
						getApp().globalData.imService.connect(currentUser);
					} 
					this.api.allFriends({}).then((res) => {
						if(res.flag){
							let userAll = 	[];
							for(let i = 0;i<res.data.length;i++){
								console.log(res.data[i])
								 let user = {
										"uuid":  res.data[i].id,
										"name": res.data[i].nickName,
										"avatar":  res.data[i].avatar
									}
								userAll.push(user) 
							}
							uni.setStorageSync('friend',userAll);
						}
					}).catch((res) =>{ });
					 setTimeout(function(){
						uni.switchTab({
							url: '../user',
						})
					},2000)
					return;
				}
				if(res.code == -2){
					return uni.showToast({
						title: '用户名不存在',
						duration: 5000,
						icon:'none'
					}); 
				}
				
				if(res.code == -3){
					return uni.showToast({
						title: '密码不正确',
						duration: 5000,
						icon:'none'
					}); 
				}
				if(res.code == -4){
					return uni.showToast({
						title: '账户被禁用请联系客服处理',
						duration: 5000,
						icon:'none'
					}); 
				}
			}).catch((err) =>{
				console.log(err)
			})
		},
		registr(){
			uni.navigateTo({
				url: '../register/register',
			});
		}
		
	}
};
</script>

<style>
.chuceanniu {
	background-size: 650rpx;
	color: white;
	display: flex;
	justify-content: center;
	align-items: center;
	width: 650rpx;
	height: 100rpx;
	background-image: url(/static/denglu/anniu121.png);
	background-repeat: no-repeat;
}
.beijingtu1 {
	display: flex;
	justify-content: center;
	align-items: flex-end;
	width: 750rpx;
	height: 450rpx;
}
.beijingtu {
	width: 400rpx;
	height: 400rpx;
	background-image: url(/static/tp/zhuce/icon.png);
	background-repeat: no-repeat;
	background-size: 400rpx;
}
</style>
