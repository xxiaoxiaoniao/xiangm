<template>
	<view style="display: flex; background-color: white;">
		<scroll-view style="width: 20%; margin-left: 20rpx;" scroll-y>
			<view :class="{ cur: index == current }" class="menu-item" v-for="(item, index) in scrollView" :key="index" @click="chooseItem(index)">{{ item.scrollV }}</view>
		</scroll-view>
	<scroll-view style="width: 80%; margin-left: 20rpx;" scroll-y>
		
	</scroll-view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				current: 0,
				scrollView:[
					{scrollV:'美妆'},
					{scrollV:'母婴'},
					{scrollV:'鞋包'},
					{scrollV:'数码'},
					{scrollV:'女装'},
					{scrollV:'食品'},
					{scrollV:'运动'},
					{scrollV:'内衣'},
					{scrollV:'家用'},
					{scrollV:'个护'},
					{scrollV:'宠物'},
					{scrollV:'医药'},
					{scrollV:'顶撞'},
					{scrollV:'服装'},
					{scrollV:'设计'},
					{scrollV:'晒红'}
				]
			}
		},
		methods: {
			chooseItem(index) {
				this.current = index;
			
				// this.getDetail(index);
			}
		}
	}
</script>

<style>
.menu-item {
	margin: 26rpx;
	padding: 0 10rpx;
}

.menu-item.cur {
	border-left: 6rpx solid #E75E5A;
	color:#E75E5A;
	height: 20rpx;
	width: 60rpx;
	line-height: 20rpx;
	
}
</style>
