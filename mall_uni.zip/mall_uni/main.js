
import Vue from 'vue'
import App from './App'
import GoEasy from "./lib/goeasy-2.2.7.min.js";
Vue.config.productionTip = false
App.mpType = 'app'

// 引入全局uView
import uView from 'uview-ui';
Vue.use(uView);

const goEasy = GoEasy.getInstance({
	host:"singapore.goeasy.io",//应用所在的区域地址: 【hangzhou.goeasy.io |singapore.goeasy.io】
	appkey:"BC-10250386b7e54057b557da4d5798ef35",	// common key,
    modules:["im"],
	// true表示支持通知栏提醒，false则表示不需要通知栏提醒
    allowNotification:true //仅有效于app,小程序和H5将会被自动忽略
});

goEasy.onClickNotification((message) => {
	let currentUrl;
	const routes = getCurrentPages();

	if ( routes &&  routes.length ) {
		const curRoute = routes[routes.length - 1].route;
		const curParam = routes[routes.length - 1].options;
		currentUrl = '/' + curRoute + `?to=${curParam.to}`;
	}
    let newUrl;
    switch(message.toType) {
        case GoEasy.IM_SCENE.PRIVATE:
            newUrl = '/pages/chat/privateChat/privateChat?to=' + message.senderId;
            break;
        case GoEasy.IM_SCENE.GROUP:
            newUrl = '/pages/chat/groupChat/groupChat?to=' + message.groupId;
            break;
    }

    if (currentUrl !== newUrl) {
        uni.navigateTo({
            url: newUrl,
        });
    }

});

Vue.prototype.GoEasy = GoEasy;
Vue.prototype.goEasy = goEasy;



Vue.prototype.formatDate = function (t) {
    t = t || Date.now();
    let time = new Date(t);
    let str = time.getMonth() < 9 ? ('0' + (time.getMonth() + 1)) : (time.getMonth() + 1);
    str += '-';
    str += time.getDate() < 10 ? ('0' + time.getDate()) : time.getDate();
    str += ' ';
    str += time.getHours();
    str += ':';
    str += time.getMinutes() < 10 ? ('0' + time.getMinutes()) : time.getMinutes();
    return str;
}

const app = new Vue({
    ...App
})
app.$mount()
// 引入请求封装，将app参数传递到配置中
require('config/request.js')(app)
app.$mount()
//全局导入api
import api from 'config/install.js'
Vue.use(api);







