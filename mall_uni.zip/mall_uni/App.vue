<script>
		import IMService from "lib/imservice";
		import restApi from "lib/restapi";
		
	export default {
		onLaunch: function() {
		},
		onShow: function() { 
			let currentUser = uni.getStorageSync('currentUser');
			if(!currentUser){
				console.log('用户还没登录')
				return;
			}
			if(this.goEasy.getConnectionStatus() === 'disconnected') {
				getApp().globalData.imService = new IMService(this.goEasy,this.GoEasy);
				getApp().globalData.imService.connect(currentUser);
			}
			this.goEasy.im.on(this.GoEasy.IM_EVENT.CONVERSATIONS_UPDATED, (content) => {
				if (content.unreadTotal > 0) {
					uni.setTabBarBadge({
						index: 3,
						text: content.unreadTotal.toString()
					});
				} else {
					uni.removeTabBarBadge({
						index: 3
					});
				}
			}); 
		},
		onHide: function() {
		},
		globalData : {
		    imService : null,
		},
		
	}
</script>

<style lang="scss">
	
	@import "uview-ui/index.scss";
	// /*每个页面公共css */
	// @import '@/uni_modules/uni-scss/index.scss';
	// /* #ifndef APP-NVUE */
	// @import '@/static/customicons.css';
	// // 设置整个项目的背景色
	
	@import 'uview-ui/index.scss';
	
	 @import url("./static/style/chatInterface.css");
	
	page {
		background-color: #f5f5f5;
	}

	/* #endif */
	.example-info {
		font-size: 14px;
		color: #333;
		padding: 10px;
	}
	
</style>
  